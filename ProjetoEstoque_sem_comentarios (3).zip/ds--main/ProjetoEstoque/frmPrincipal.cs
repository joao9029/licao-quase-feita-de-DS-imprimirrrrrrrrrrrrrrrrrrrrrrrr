﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoEstoque
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }
        private void relatórioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void usuáriosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmUsuario fu = new frmUsuario();
            fu.ShowDialog();
        } 

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmFornecedor ff = new frmFornecedor();
            ff.ShowDialog();
        }

        private void clientesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmCliente fc = new frmCliente();
            fc.ShowDialog();
        }

        private void produtosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmProduto fp = new frmProduto();
            fp.ShowDialog();
        }

        private void ExibirRelatorio(string titulo, Func<DataTable> obterDados, string[] campos,
                                     string[] cabecalhos, float[] larguras)
        {
            DataTable dados;
            try
            {
                dados = obterDados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Não foi possível ler os dados do banco.\n\nDetalhe: " + ex.Message,
                    titulo, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Impressao.Imprimir(titulo, dados, campos, cabecalhos, larguras);
        }

        private void relatorioUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibirRelatorio("Relatório de Usuários",
                () =>
                {
                    using (var ta = new bancoDataSet1TableAdapters.tb_usuarioTableAdapter())
                        return (DataTable)ta.GetData();
                },
                new string[] { "cd_usuario", "nm_usuario", "sg_nivel", "nm_login" },
                new string[] { "Código", "Nome", "Nível", "Login" },
                new float[] { 8, 40, 12, 25 });
        }

        private void relatorioFornecedoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibirRelatorio("Relatório de Fornecedores",
                () =>
                {
                    using (var ta = new bancoDataSet1TableAdapters.tb_fornecedorTableAdapter())
                        return (DataTable)ta.GetData();
                },
                new string[] { "cd_fornecedor", "nm_fornecedor", "ds_endereco", "nm_bairro", "nm_cidade", "sg_estado", "cd_cep", "cd_cnpj", "cd_ie" },
                new string[] { "Código", "Nome", "Endereço", "Bairro", "Cidade", "UF", "CEP", "CNPJ", "IE" },
                new float[] { 6, 20, 20, 12, 12, 4, 9, 12, 9 });
        }

        private void relatorioClientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibirRelatorio("Relatório de Clientes",
                () =>
                {
                    using (var ta = new bancoDataSet1TableAdapters.tb_clienteTableAdapter())
                        return (DataTable)ta.GetData();
                },
                new string[] { "cd_cliente", "nm_cliente", "ds_endereco", "nm_bairro", "nm_cidade", "sg_estado", "cd_cep", "cd_cpf", "cd_rg" },
                new string[] { "Código", "Nome", "Endereço", "Bairro", "Cidade", "UF", "CEP", "CPF", "RG" },
                new float[] { 6, 20, 20, 12, 12, 4, 9, 11, 9 });
        }

        private void relatorioProdutosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibirRelatorio("Relatório de Produtos",
                () =>
                {
                    using (var ta = new bancoDataSet1TableAdapters.tb_produtosTableAdapter())
                        return (DataTable)ta.GetData();
                },
                new string[] { "cd_produto", "nm_produto", "sg_unidade_venda_produto", "vl_custo", "vl_venda", "qt_estoque" },
                new string[] { "Código", "Produto", "Unidade", "Custo", "Venda", "Estoque" },
                new float[] { 8, 36, 10, 12, 12, 10 });
        }
    }
}
