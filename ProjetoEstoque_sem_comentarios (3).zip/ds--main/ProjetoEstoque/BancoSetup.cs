﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ProjetoEstoque
{
    internal static class BancoSetup
    {
        private static readonly string[] comandos = new string[]
        {
            @"IF OBJECT_ID(N'dbo.tb_produtos', N'U') IS NULL
              BEGIN
                  IF OBJECT_ID(N'dbo.tb_funcionario', N'U') IS NOT NULL
                     AND COL_LENGTH(N'dbo.tb_funcionario', N'cd_produto') IS NOT NULL
                      EXEC sp_rename N'dbo.tb_funcionario', N'tb_produtos';
                  ELSE
                      CREATE TABLE dbo.tb_produtos
                      (
                          cd_produto int IDENTITY(1,1) NOT NULL PRIMARY KEY,
                          nm_produto varchar(50) NOT NULL,
                          sg_unidade_venda_produto varchar(2) NULL,
                          vl_custo decimal(14,2) NULL,
                          vl_venda decimal(14,2) NULL,
                          qt_estoque int NULL
                      );
              END",

            @"IF COL_LENGTH(N'dbo.tb_produtos', N'sg_unidade_venda_produto') IS NULL
                 AND COL_LENGTH(N'dbo.tb_produtos', N'sg_unidade_venda') IS NOT NULL
                  EXEC sp_rename N'dbo.tb_produtos.sg_unidade_venda', N'sg_unidade_venda_produto', N'COLUMN';",

            @"IF COL_LENGTH(N'dbo.tb_cliente', N'cd_rg') IS NULL
                  ALTER TABLE dbo.tb_cliente ADD cd_rg varchar(15) NULL;",

            @"IF COL_LENGTH(N'dbo.tb_fornecedor', N'cd_ie') IS NULL
                  ALTER TABLE dbo.tb_fornecedor ADD cd_ie varchar(15) NULL;"
        };

        public static void Garantir()
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(Properties.Settings.Default.bancoConnectionString))
                {
                    cn.Open();
                    foreach (string sql in comandos)
                    {
                        using (SqlCommand cmd = new SqlCommand(sql, cn))
                            cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Não foi possível preparar o banco de dados.\n\n" +
                    "Instale o SQL Server Express LocalDB (Visual Studio Installer > Modificar > " +
                    "Componentes individuais > SQL Server Express LocalDB) e tente novamente.\n\n" +
                    "Detalhe: " + ex.Message,
                    "Banco de dados", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
