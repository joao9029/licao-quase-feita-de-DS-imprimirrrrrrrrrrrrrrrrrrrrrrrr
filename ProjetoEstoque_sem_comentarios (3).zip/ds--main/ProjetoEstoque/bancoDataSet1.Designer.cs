﻿
#pragma warning disable 1591

namespace ProjetoEstoque {
    
    
    [global::System.Serializable()]
    [global::System.ComponentModel.DesignerCategoryAttribute("code")]
    [global::System.ComponentModel.ToolboxItem(true)]
    [global::System.Xml.Serialization.XmlSchemaProviderAttribute("GetTypedDataSetSchema")]
    [global::System.Xml.Serialization.XmlRootAttribute("bancoDataSet1")]
    [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.DataSet")]
    public partial class bancoDataSet1 : global::System.Data.DataSet {
        
        private tb_clienteDataTable tabletb_cliente;
        
        private tb_fornecedorDataTable tabletb_fornecedor;
        
        private tb_usuarioDataTable tabletb_usuario;
        
        private tb_produtosDataTable tabletb_produtos;
        
        private global::System.Data.SchemaSerializationMode _schemaSerializationMode = global::System.Data.SchemaSerializationMode.IncludeSchema;
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public bancoDataSet1() {
            this.BeginInit();
            this.InitClass();
            global::System.ComponentModel.CollectionChangeEventHandler schemaChangedHandler = new global::System.ComponentModel.CollectionChangeEventHandler(this.SchemaChanged);
            base.Tables.CollectionChanged += schemaChangedHandler;
            base.Relations.CollectionChanged += schemaChangedHandler;
            this.EndInit();
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected bancoDataSet1(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) : 
                base(info, context, false) {
            if ((this.IsBinarySerialized(info, context) == true)) {
                this.InitVars(false);
                global::System.ComponentModel.CollectionChangeEventHandler schemaChangedHandler1 = new global::System.ComponentModel.CollectionChangeEventHandler(this.SchemaChanged);
                this.Tables.CollectionChanged += schemaChangedHandler1;
                this.Relations.CollectionChanged += schemaChangedHandler1;
                return;
            }
            string strSchema = ((string)(info.GetValue("XmlSchema", typeof(string))));
            if ((this.DetermineSchemaSerializationMode(info, context) == global::System.Data.SchemaSerializationMode.IncludeSchema)) {
                global::System.Data.DataSet ds = new global::System.Data.DataSet();
                ds.ReadXmlSchema(new global::System.Xml.XmlTextReader(new global::System.IO.StringReader(strSchema)));
                if ((ds.Tables["tb_cliente"] != null)) {
                    base.Tables.Add(new tb_clienteDataTable(ds.Tables["tb_cliente"]));
                }
                if ((ds.Tables["tb_fornecedor"] != null)) {
                    base.Tables.Add(new tb_fornecedorDataTable(ds.Tables["tb_fornecedor"]));
                }
                if ((ds.Tables["tb_usuario"] != null)) {
                    base.Tables.Add(new tb_usuarioDataTable(ds.Tables["tb_usuario"]));
                }
                if ((ds.Tables["tb_produtos"] != null)) {
                    base.Tables.Add(new tb_produtosDataTable(ds.Tables["tb_produtos"]));
                }
                this.DataSetName = ds.DataSetName;
                this.Prefix = ds.Prefix;
                this.Namespace = ds.Namespace;
                this.Locale = ds.Locale;
                this.CaseSensitive = ds.CaseSensitive;
                this.EnforceConstraints = ds.EnforceConstraints;
                this.Merge(ds, false, global::System.Data.MissingSchemaAction.Add);
                this.InitVars();
            }
            else {
                this.ReadXmlSchema(new global::System.Xml.XmlTextReader(new global::System.IO.StringReader(strSchema)));
            }
            this.GetSerializationData(info, context);
            global::System.ComponentModel.CollectionChangeEventHandler schemaChangedHandler = new global::System.ComponentModel.CollectionChangeEventHandler(this.SchemaChanged);
            base.Tables.CollectionChanged += schemaChangedHandler;
            this.Relations.CollectionChanged += schemaChangedHandler;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Browsable(false)]
        [global::System.ComponentModel.DesignerSerializationVisibility(global::System.ComponentModel.DesignerSerializationVisibility.Content)]
        public tb_clienteDataTable tb_cliente {
            get {
                return this.tabletb_cliente;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Browsable(false)]
        [global::System.ComponentModel.DesignerSerializationVisibility(global::System.ComponentModel.DesignerSerializationVisibility.Content)]
        public tb_fornecedorDataTable tb_fornecedor {
            get {
                return this.tabletb_fornecedor;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Browsable(false)]
        [global::System.ComponentModel.DesignerSerializationVisibility(global::System.ComponentModel.DesignerSerializationVisibility.Content)]
        public tb_usuarioDataTable tb_usuario {
            get {
                return this.tabletb_usuario;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Browsable(false)]
        [global::System.ComponentModel.DesignerSerializationVisibility(global::System.ComponentModel.DesignerSerializationVisibility.Content)]
        public tb_produtosDataTable tb_produtos {
            get {
                return this.tabletb_produtos;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.BrowsableAttribute(true)]
        [global::System.ComponentModel.DesignerSerializationVisibilityAttribute(global::System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public override global::System.Data.SchemaSerializationMode SchemaSerializationMode {
            get {
                return this._schemaSerializationMode;
            }
            set {
                this._schemaSerializationMode = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.DesignerSerializationVisibilityAttribute(global::System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public new global::System.Data.DataTableCollection Tables {
            get {
                return base.Tables;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.DesignerSerializationVisibilityAttribute(global::System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public new global::System.Data.DataRelationCollection Relations {
            get {
                return base.Relations;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected override void InitializeDerivedDataSet() {
            this.BeginInit();
            this.InitClass();
            this.EndInit();
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public override global::System.Data.DataSet Clone() {
            bancoDataSet1 cln = ((bancoDataSet1)(base.Clone()));
            cln.InitVars();
            cln.SchemaSerializationMode = this.SchemaSerializationMode;
            return cln;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected override bool ShouldSerializeTables() {
            return false;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected override bool ShouldSerializeRelations() {
            return false;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected override void ReadXmlSerializable(global::System.Xml.XmlReader reader) {
            if ((this.DetermineSchemaSerializationMode(reader) == global::System.Data.SchemaSerializationMode.IncludeSchema)) {
                this.Reset();
                global::System.Data.DataSet ds = new global::System.Data.DataSet();
                ds.ReadXml(reader);
                if ((ds.Tables["tb_cliente"] != null)) {
                    base.Tables.Add(new tb_clienteDataTable(ds.Tables["tb_cliente"]));
                }
                if ((ds.Tables["tb_fornecedor"] != null)) {
                    base.Tables.Add(new tb_fornecedorDataTable(ds.Tables["tb_fornecedor"]));
                }
                if ((ds.Tables["tb_usuario"] != null)) {
                    base.Tables.Add(new tb_usuarioDataTable(ds.Tables["tb_usuario"]));
                }
                if ((ds.Tables["tb_produtos"] != null)) {
                    base.Tables.Add(new tb_produtosDataTable(ds.Tables["tb_produtos"]));
                }
                this.DataSetName = ds.DataSetName;
                this.Prefix = ds.Prefix;
                this.Namespace = ds.Namespace;
                this.Locale = ds.Locale;
                this.CaseSensitive = ds.CaseSensitive;
                this.EnforceConstraints = ds.EnforceConstraints;
                this.Merge(ds, false, global::System.Data.MissingSchemaAction.Add);
                this.InitVars();
            }
            else {
                this.ReadXml(reader);
                this.InitVars();
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected override global::System.Xml.Schema.XmlSchema GetSchemaSerializable() {
            global::System.IO.MemoryStream stream = new global::System.IO.MemoryStream();
            this.WriteXmlSchema(new global::System.Xml.XmlTextWriter(stream, null));
            stream.Position = 0;
            return global::System.Xml.Schema.XmlSchema.Read(new global::System.Xml.XmlTextReader(stream), null);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal void InitVars() {
            this.InitVars(true);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal void InitVars(bool initTable) {
            this.tabletb_cliente = ((tb_clienteDataTable)(base.Tables["tb_cliente"]));
            if ((initTable == true)) {
                if ((this.tabletb_cliente != null)) {
                    this.tabletb_cliente.InitVars();
                }
            }
            this.tabletb_fornecedor = ((tb_fornecedorDataTable)(base.Tables["tb_fornecedor"]));
            if ((initTable == true)) {
                if ((this.tabletb_fornecedor != null)) {
                    this.tabletb_fornecedor.InitVars();
                }
            }
            this.tabletb_usuario = ((tb_usuarioDataTable)(base.Tables["tb_usuario"]));
            if ((initTable == true)) {
                if ((this.tabletb_usuario != null)) {
                    this.tabletb_usuario.InitVars();
                }
            }
            this.tabletb_produtos = ((tb_produtosDataTable)(base.Tables["tb_produtos"]));
            if ((initTable == true)) {
                if ((this.tabletb_produtos != null)) {
                    this.tabletb_produtos.InitVars();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitClass() {
            this.DataSetName = "bancoDataSet1";
            this.Prefix = "";
            this.Namespace = "http://tempuri.org/bancoDataSet1.xsd";
            this.EnforceConstraints = true;
            this.SchemaSerializationMode = global::System.Data.SchemaSerializationMode.IncludeSchema;
            this.tabletb_cliente = new tb_clienteDataTable();
            base.Tables.Add(this.tabletb_cliente);
            this.tabletb_fornecedor = new tb_fornecedorDataTable();
            base.Tables.Add(this.tabletb_fornecedor);
            this.tabletb_usuario = new tb_usuarioDataTable();
            base.Tables.Add(this.tabletb_usuario);
            this.tabletb_produtos = new tb_produtosDataTable();
            base.Tables.Add(this.tabletb_produtos);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private bool ShouldSerializetb_cliente() {
            return false;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private bool ShouldSerializetb_fornecedor() {
            return false;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private bool ShouldSerializetb_usuario() {
            return false;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private bool ShouldSerializetb_produtos() {
            return false;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void SchemaChanged(object sender, global::System.ComponentModel.CollectionChangeEventArgs e) {
            if ((e.Action == global::System.ComponentModel.CollectionChangeAction.Remove)) {
                this.InitVars();
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public static global::System.Xml.Schema.XmlSchemaComplexType GetTypedDataSetSchema(global::System.Xml.Schema.XmlSchemaSet xs) {
            bancoDataSet1 ds = new bancoDataSet1();
            global::System.Xml.Schema.XmlSchemaComplexType type = new global::System.Xml.Schema.XmlSchemaComplexType();
            global::System.Xml.Schema.XmlSchemaSequence sequence = new global::System.Xml.Schema.XmlSchemaSequence();
            global::System.Xml.Schema.XmlSchemaAny any = new global::System.Xml.Schema.XmlSchemaAny();
            any.Namespace = ds.Namespace;
            sequence.Items.Add(any);
            type.Particle = sequence;
            global::System.Xml.Schema.XmlSchema dsSchema = ds.GetSchemaSerializable();
            if (xs.Contains(dsSchema.TargetNamespace)) {
                global::System.IO.MemoryStream s1 = new global::System.IO.MemoryStream();
                global::System.IO.MemoryStream s2 = new global::System.IO.MemoryStream();
                try {
                    global::System.Xml.Schema.XmlSchema schema = null;
                    dsSchema.Write(s1);
                    for (global::System.Collections.IEnumerator schemas = xs.Schemas(dsSchema.TargetNamespace).GetEnumerator(); schemas.MoveNext(); ) {
                        schema = ((global::System.Xml.Schema.XmlSchema)(schemas.Current));
                        s2.SetLength(0);
                        schema.Write(s2);
                        if ((s1.Length == s2.Length)) {
                            s1.Position = 0;
                            s2.Position = 0;
                            for (; ((s1.Position != s1.Length) 
                                        && (s1.ReadByte() == s2.ReadByte())); ) {
                                ;
                            }
                            if ((s1.Position == s1.Length)) {
                                return type;
                            }
                        }
                    }
                }
                finally {
                    if ((s1 != null)) {
                        s1.Close();
                    }
                    if ((s2 != null)) {
                        s2.Close();
                    }
                }
            }
            xs.Add(dsSchema);
            return type;
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public delegate void tb_clienteRowChangeEventHandler(object sender, tb_clienteRowChangeEvent e);
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public delegate void tb_fornecedorRowChangeEventHandler(object sender, tb_fornecedorRowChangeEvent e);
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public delegate void tb_usuarioRowChangeEventHandler(object sender, tb_usuarioRowChangeEvent e);
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public delegate void tb_produtosRowChangeEventHandler(object sender, tb_produtosRowChangeEvent e);
        
        [global::System.Serializable()]
        [global::System.Xml.Serialization.XmlSchemaProviderAttribute("GetTypedTableSchema")]
        public partial class tb_clienteDataTable : global::System.Data.TypedTableBase<tb_clienteRow> {
            
            private global::System.Data.DataColumn columncd_cliente;
            
            private global::System.Data.DataColumn columnnm_cliente;
            
            private global::System.Data.DataColumn columnds_endereco;
            
            private global::System.Data.DataColumn columnnm_bairro;
            
            private global::System.Data.DataColumn columnnm_cidade;
            
            private global::System.Data.DataColumn columnsg_estado;
            
            private global::System.Data.DataColumn columncd_cep;
            
            private global::System.Data.DataColumn columncd_cpf;
            
            private global::System.Data.DataColumn columncd_rg;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteDataTable() {
                this.TableName = "tb_cliente";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_clienteDataTable(global::System.Data.DataTable table) {
                this.TableName = table.TableName;
                if ((table.CaseSensitive != table.DataSet.CaseSensitive)) {
                    this.CaseSensitive = table.CaseSensitive;
                }
                if ((table.Locale.ToString() != table.DataSet.Locale.ToString())) {
                    this.Locale = table.Locale;
                }
                if ((table.Namespace != table.DataSet.Namespace)) {
                    this.Namespace = table.Namespace;
                }
                this.Prefix = table.Prefix;
                this.MinimumCapacity = table.MinimumCapacity;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected tb_clienteDataTable(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) : 
                    base(info, context) {
                this.InitVars();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_clienteColumn {
                get {
                    return this.columncd_cliente;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_clienteColumn {
                get {
                    return this.columnnm_cliente;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn ds_enderecoColumn {
                get {
                    return this.columnds_endereco;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_bairroColumn {
                get {
                    return this.columnnm_bairro;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_cidadeColumn {
                get {
                    return this.columnnm_cidade;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn sg_estadoColumn {
                get {
                    return this.columnsg_estado;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_cepColumn {
                get {
                    return this.columncd_cep;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_cpfColumn {
                get {
                    return this.columncd_cpf;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_rgColumn {
                get {
                    return this.columncd_rg;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            [global::System.ComponentModel.Browsable(false)]
            public int Count {
                get {
                    return this.Rows.Count;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteRow this[int index] {
                get {
                    return ((tb_clienteRow)(this.Rows[index]));
                }
            }
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_clienteRowChangeEventHandler tb_clienteRowChanging;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_clienteRowChangeEventHandler tb_clienteRowChanged;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_clienteRowChangeEventHandler tb_clienteRowDeleting;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_clienteRowChangeEventHandler tb_clienteRowDeleted;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Addtb_clienteRow(tb_clienteRow row) {
                this.Rows.Add(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteRow Addtb_clienteRow(string nm_cliente, string ds_endereco, string nm_bairro, string nm_cidade, string sg_estado, string cd_cep, string cd_cpf, string cd_rg) {
                tb_clienteRow rowtb_clienteRow = ((tb_clienteRow)(this.NewRow()));
                object[] columnValuesArray = new object[] {
                        null,
                        nm_cliente,
                        ds_endereco,
                        nm_bairro,
                        nm_cidade,
                        sg_estado,
                        cd_cep,
                        cd_cpf,
                        cd_rg};
                rowtb_clienteRow.ItemArray = columnValuesArray;
                this.Rows.Add(rowtb_clienteRow);
                return rowtb_clienteRow;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteRow FindBycd_cliente(int cd_cliente) {
                return ((tb_clienteRow)(this.Rows.Find(new object[] {
                            cd_cliente})));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public override global::System.Data.DataTable Clone() {
                tb_clienteDataTable cln = ((tb_clienteDataTable)(base.Clone()));
                cln.InitVars();
                return cln;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataTable CreateInstance() {
                return new tb_clienteDataTable();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal void InitVars() {
                this.columncd_cliente = base.Columns["cd_cliente"];
                this.columnnm_cliente = base.Columns["nm_cliente"];
                this.columnds_endereco = base.Columns["ds_endereco"];
                this.columnnm_bairro = base.Columns["nm_bairro"];
                this.columnnm_cidade = base.Columns["nm_cidade"];
                this.columnsg_estado = base.Columns["sg_estado"];
                this.columncd_cep = base.Columns["cd_cep"];
                this.columncd_cpf = base.Columns["cd_cpf"];
                this.columncd_rg = base.Columns["cd_rg"];
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            private void InitClass() {
                this.columncd_cliente = new global::System.Data.DataColumn("cd_cliente", typeof(int), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_cliente);
                this.columnnm_cliente = new global::System.Data.DataColumn("nm_cliente", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_cliente);
                this.columnds_endereco = new global::System.Data.DataColumn("ds_endereco", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnds_endereco);
                this.columnnm_bairro = new global::System.Data.DataColumn("nm_bairro", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_bairro);
                this.columnnm_cidade = new global::System.Data.DataColumn("nm_cidade", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_cidade);
                this.columnsg_estado = new global::System.Data.DataColumn("sg_estado", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnsg_estado);
                this.columncd_cep = new global::System.Data.DataColumn("cd_cep", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_cep);
                this.columncd_cpf = new global::System.Data.DataColumn("cd_cpf", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_cpf);
                this.columncd_rg = new global::System.Data.DataColumn("cd_rg", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_rg);
                this.Constraints.Add(new global::System.Data.UniqueConstraint("Constraint1", new global::System.Data.DataColumn[] {
                                this.columncd_cliente}, true));
                this.columncd_cliente.AutoIncrement = true;
                this.columncd_cliente.AutoIncrementSeed = -1;
                this.columncd_cliente.AutoIncrementStep = -1;
                this.columncd_cliente.AllowDBNull = false;
                this.columncd_cliente.ReadOnly = true;
                this.columncd_cliente.Unique = true;
                this.columnnm_cliente.MaxLength = 50;
                this.columnds_endereco.MaxLength = 50;
                this.columnnm_bairro.MaxLength = 50;
                this.columnnm_cidade.MaxLength = 30;
                this.columnsg_estado.MaxLength = 2;
                this.columncd_cep.MaxLength = 8;
                this.columncd_cpf.MaxLength = 14;
                this.columncd_rg.MaxLength = 15;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteRow Newtb_clienteRow() {
                return ((tb_clienteRow)(this.NewRow()));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataRow NewRowFromBuilder(global::System.Data.DataRowBuilder builder) {
                return new tb_clienteRow(builder);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Type GetRowType() {
                return typeof(tb_clienteRow);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanged(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanged(e);
                if ((this.tb_clienteRowChanged != null)) {
                    this.tb_clienteRowChanged(this, new tb_clienteRowChangeEvent(((tb_clienteRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanging(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanging(e);
                if ((this.tb_clienteRowChanging != null)) {
                    this.tb_clienteRowChanging(this, new tb_clienteRowChangeEvent(((tb_clienteRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleted(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleted(e);
                if ((this.tb_clienteRowDeleted != null)) {
                    this.tb_clienteRowDeleted(this, new tb_clienteRowChangeEvent(((tb_clienteRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleting(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleting(e);
                if ((this.tb_clienteRowDeleting != null)) {
                    this.tb_clienteRowDeleting(this, new tb_clienteRowChangeEvent(((tb_clienteRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Removetb_clienteRow(tb_clienteRow row) {
                this.Rows.Remove(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public static global::System.Xml.Schema.XmlSchemaComplexType GetTypedTableSchema(global::System.Xml.Schema.XmlSchemaSet xs) {
                global::System.Xml.Schema.XmlSchemaComplexType type = new global::System.Xml.Schema.XmlSchemaComplexType();
                global::System.Xml.Schema.XmlSchemaSequence sequence = new global::System.Xml.Schema.XmlSchemaSequence();
                bancoDataSet1 ds = new bancoDataSet1();
                global::System.Xml.Schema.XmlSchemaAny any1 = new global::System.Xml.Schema.XmlSchemaAny();
                any1.Namespace = "http://www.w3.org/2001/XMLSchema";
                any1.MinOccurs = new decimal(0);
                any1.MaxOccurs = decimal.MaxValue;
                any1.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any1);
                global::System.Xml.Schema.XmlSchemaAny any2 = new global::System.Xml.Schema.XmlSchemaAny();
                any2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
                any2.MinOccurs = new decimal(1);
                any2.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any2);
                global::System.Xml.Schema.XmlSchemaAttribute attribute1 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute1.Name = "namespace";
                attribute1.FixedValue = ds.Namespace;
                type.Attributes.Add(attribute1);
                global::System.Xml.Schema.XmlSchemaAttribute attribute2 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute2.Name = "tableTypeName";
                attribute2.FixedValue = "tb_clienteDataTable";
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                global::System.Xml.Schema.XmlSchema dsSchema = ds.GetSchemaSerializable();
                if (xs.Contains(dsSchema.TargetNamespace)) {
                    global::System.IO.MemoryStream s1 = new global::System.IO.MemoryStream();
                    global::System.IO.MemoryStream s2 = new global::System.IO.MemoryStream();
                    try {
                        global::System.Xml.Schema.XmlSchema schema = null;
                        dsSchema.Write(s1);
                        for (global::System.Collections.IEnumerator schemas = xs.Schemas(dsSchema.TargetNamespace).GetEnumerator(); schemas.MoveNext(); ) {
                            schema = ((global::System.Xml.Schema.XmlSchema)(schemas.Current));
                            s2.SetLength(0);
                            schema.Write(s2);
                            if ((s1.Length == s2.Length)) {
                                s1.Position = 0;
                                s2.Position = 0;
                                for (; ((s1.Position != s1.Length) 
                                            && (s1.ReadByte() == s2.ReadByte())); ) {
                                    ;
                                }
                                if ((s1.Position == s1.Length)) {
                                    return type;
                                }
                            }
                        }
                    }
                    finally {
                        if ((s1 != null)) {
                            s1.Close();
                        }
                        if ((s2 != null)) {
                            s2.Close();
                        }
                    }
                }
                xs.Add(dsSchema);
                return type;
            }
        }
        
        [global::System.Serializable()]
        [global::System.Xml.Serialization.XmlSchemaProviderAttribute("GetTypedTableSchema")]
        public partial class tb_fornecedorDataTable : global::System.Data.TypedTableBase<tb_fornecedorRow> {
            
            private global::System.Data.DataColumn columncd_fornecedor;
            
            private global::System.Data.DataColumn columnnm_fornecedor;
            
            private global::System.Data.DataColumn columnds_endereco;
            
            private global::System.Data.DataColumn columnnm_bairro;
            
            private global::System.Data.DataColumn columnnm_cidade;
            
            private global::System.Data.DataColumn columnsg_estado;
            
            private global::System.Data.DataColumn columncd_cep;
            
            private global::System.Data.DataColumn columncd_cnpj;
            
            private global::System.Data.DataColumn columncd_ie;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorDataTable() {
                this.TableName = "tb_fornecedor";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_fornecedorDataTable(global::System.Data.DataTable table) {
                this.TableName = table.TableName;
                if ((table.CaseSensitive != table.DataSet.CaseSensitive)) {
                    this.CaseSensitive = table.CaseSensitive;
                }
                if ((table.Locale.ToString() != table.DataSet.Locale.ToString())) {
                    this.Locale = table.Locale;
                }
                if ((table.Namespace != table.DataSet.Namespace)) {
                    this.Namespace = table.Namespace;
                }
                this.Prefix = table.Prefix;
                this.MinimumCapacity = table.MinimumCapacity;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected tb_fornecedorDataTable(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) : 
                    base(info, context) {
                this.InitVars();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_fornecedorColumn {
                get {
                    return this.columncd_fornecedor;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_fornecedorColumn {
                get {
                    return this.columnnm_fornecedor;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn ds_enderecoColumn {
                get {
                    return this.columnds_endereco;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_bairroColumn {
                get {
                    return this.columnnm_bairro;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_cidadeColumn {
                get {
                    return this.columnnm_cidade;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn sg_estadoColumn {
                get {
                    return this.columnsg_estado;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_cepColumn {
                get {
                    return this.columncd_cep;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_cnpjColumn {
                get {
                    return this.columncd_cnpj;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_ieColumn {
                get {
                    return this.columncd_ie;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            [global::System.ComponentModel.Browsable(false)]
            public int Count {
                get {
                    return this.Rows.Count;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorRow this[int index] {
                get {
                    return ((tb_fornecedorRow)(this.Rows[index]));
                }
            }
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_fornecedorRowChangeEventHandler tb_fornecedorRowChanging;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_fornecedorRowChangeEventHandler tb_fornecedorRowChanged;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_fornecedorRowChangeEventHandler tb_fornecedorRowDeleting;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_fornecedorRowChangeEventHandler tb_fornecedorRowDeleted;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Addtb_fornecedorRow(tb_fornecedorRow row) {
                this.Rows.Add(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorRow Addtb_fornecedorRow(string nm_fornecedor, string ds_endereco, string nm_bairro, string nm_cidade, string sg_estado, string cd_cep, string cd_cnpj, string cd_ie) {
                tb_fornecedorRow rowtb_fornecedorRow = ((tb_fornecedorRow)(this.NewRow()));
                object[] columnValuesArray = new object[] {
                        null,
                        nm_fornecedor,
                        ds_endereco,
                        nm_bairro,
                        nm_cidade,
                        sg_estado,
                        cd_cep,
                        cd_cnpj,
                        cd_ie};
                rowtb_fornecedorRow.ItemArray = columnValuesArray;
                this.Rows.Add(rowtb_fornecedorRow);
                return rowtb_fornecedorRow;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorRow FindBycd_fornecedor(int cd_fornecedor) {
                return ((tb_fornecedorRow)(this.Rows.Find(new object[] {
                            cd_fornecedor})));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public override global::System.Data.DataTable Clone() {
                tb_fornecedorDataTable cln = ((tb_fornecedorDataTable)(base.Clone()));
                cln.InitVars();
                return cln;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataTable CreateInstance() {
                return new tb_fornecedorDataTable();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal void InitVars() {
                this.columncd_fornecedor = base.Columns["cd_fornecedor"];
                this.columnnm_fornecedor = base.Columns["nm_fornecedor"];
                this.columnds_endereco = base.Columns["ds_endereco"];
                this.columnnm_bairro = base.Columns["nm_bairro"];
                this.columnnm_cidade = base.Columns["nm_cidade"];
                this.columnsg_estado = base.Columns["sg_estado"];
                this.columncd_cep = base.Columns["cd_cep"];
                this.columncd_cnpj = base.Columns["cd_cnpj"];
                this.columncd_ie = base.Columns["cd_ie"];
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            private void InitClass() {
                this.columncd_fornecedor = new global::System.Data.DataColumn("cd_fornecedor", typeof(int), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_fornecedor);
                this.columnnm_fornecedor = new global::System.Data.DataColumn("nm_fornecedor", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_fornecedor);
                this.columnds_endereco = new global::System.Data.DataColumn("ds_endereco", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnds_endereco);
                this.columnnm_bairro = new global::System.Data.DataColumn("nm_bairro", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_bairro);
                this.columnnm_cidade = new global::System.Data.DataColumn("nm_cidade", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_cidade);
                this.columnsg_estado = new global::System.Data.DataColumn("sg_estado", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnsg_estado);
                this.columncd_cep = new global::System.Data.DataColumn("cd_cep", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_cep);
                this.columncd_cnpj = new global::System.Data.DataColumn("cd_cnpj", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_cnpj);
                this.columncd_ie = new global::System.Data.DataColumn("cd_ie", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_ie);
                this.Constraints.Add(new global::System.Data.UniqueConstraint("Constraint1", new global::System.Data.DataColumn[] {
                                this.columncd_fornecedor}, true));
                this.columncd_fornecedor.AutoIncrement = true;
                this.columncd_fornecedor.AutoIncrementSeed = -1;
                this.columncd_fornecedor.AutoIncrementStep = -1;
                this.columncd_fornecedor.AllowDBNull = false;
                this.columncd_fornecedor.ReadOnly = true;
                this.columncd_fornecedor.Unique = true;
                this.columnnm_fornecedor.MaxLength = 50;
                this.columnds_endereco.MaxLength = 50;
                this.columnnm_bairro.MaxLength = 30;
                this.columnnm_cidade.MaxLength = 30;
                this.columnsg_estado.MaxLength = 2;
                this.columncd_cep.MaxLength = 9;
                this.columncd_cnpj.MaxLength = 18;
                this.columncd_ie.MaxLength = 15;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorRow Newtb_fornecedorRow() {
                return ((tb_fornecedorRow)(this.NewRow()));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataRow NewRowFromBuilder(global::System.Data.DataRowBuilder builder) {
                return new tb_fornecedorRow(builder);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Type GetRowType() {
                return typeof(tb_fornecedorRow);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanged(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanged(e);
                if ((this.tb_fornecedorRowChanged != null)) {
                    this.tb_fornecedorRowChanged(this, new tb_fornecedorRowChangeEvent(((tb_fornecedorRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanging(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanging(e);
                if ((this.tb_fornecedorRowChanging != null)) {
                    this.tb_fornecedorRowChanging(this, new tb_fornecedorRowChangeEvent(((tb_fornecedorRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleted(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleted(e);
                if ((this.tb_fornecedorRowDeleted != null)) {
                    this.tb_fornecedorRowDeleted(this, new tb_fornecedorRowChangeEvent(((tb_fornecedorRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleting(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleting(e);
                if ((this.tb_fornecedorRowDeleting != null)) {
                    this.tb_fornecedorRowDeleting(this, new tb_fornecedorRowChangeEvent(((tb_fornecedorRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Removetb_fornecedorRow(tb_fornecedorRow row) {
                this.Rows.Remove(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public static global::System.Xml.Schema.XmlSchemaComplexType GetTypedTableSchema(global::System.Xml.Schema.XmlSchemaSet xs) {
                global::System.Xml.Schema.XmlSchemaComplexType type = new global::System.Xml.Schema.XmlSchemaComplexType();
                global::System.Xml.Schema.XmlSchemaSequence sequence = new global::System.Xml.Schema.XmlSchemaSequence();
                bancoDataSet1 ds = new bancoDataSet1();
                global::System.Xml.Schema.XmlSchemaAny any1 = new global::System.Xml.Schema.XmlSchemaAny();
                any1.Namespace = "http://www.w3.org/2001/XMLSchema";
                any1.MinOccurs = new decimal(0);
                any1.MaxOccurs = decimal.MaxValue;
                any1.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any1);
                global::System.Xml.Schema.XmlSchemaAny any2 = new global::System.Xml.Schema.XmlSchemaAny();
                any2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
                any2.MinOccurs = new decimal(1);
                any2.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any2);
                global::System.Xml.Schema.XmlSchemaAttribute attribute1 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute1.Name = "namespace";
                attribute1.FixedValue = ds.Namespace;
                type.Attributes.Add(attribute1);
                global::System.Xml.Schema.XmlSchemaAttribute attribute2 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute2.Name = "tableTypeName";
                attribute2.FixedValue = "tb_fornecedorDataTable";
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                global::System.Xml.Schema.XmlSchema dsSchema = ds.GetSchemaSerializable();
                if (xs.Contains(dsSchema.TargetNamespace)) {
                    global::System.IO.MemoryStream s1 = new global::System.IO.MemoryStream();
                    global::System.IO.MemoryStream s2 = new global::System.IO.MemoryStream();
                    try {
                        global::System.Xml.Schema.XmlSchema schema = null;
                        dsSchema.Write(s1);
                        for (global::System.Collections.IEnumerator schemas = xs.Schemas(dsSchema.TargetNamespace).GetEnumerator(); schemas.MoveNext(); ) {
                            schema = ((global::System.Xml.Schema.XmlSchema)(schemas.Current));
                            s2.SetLength(0);
                            schema.Write(s2);
                            if ((s1.Length == s2.Length)) {
                                s1.Position = 0;
                                s2.Position = 0;
                                for (; ((s1.Position != s1.Length) 
                                            && (s1.ReadByte() == s2.ReadByte())); ) {
                                    ;
                                }
                                if ((s1.Position == s1.Length)) {
                                    return type;
                                }
                            }
                        }
                    }
                    finally {
                        if ((s1 != null)) {
                            s1.Close();
                        }
                        if ((s2 != null)) {
                            s2.Close();
                        }
                    }
                }
                xs.Add(dsSchema);
                return type;
            }
        }
        
        [global::System.Serializable()]
        [global::System.Xml.Serialization.XmlSchemaProviderAttribute("GetTypedTableSchema")]
        public partial class tb_usuarioDataTable : global::System.Data.TypedTableBase<tb_usuarioRow> {
            
            private global::System.Data.DataColumn columncd_usuario;
            
            private global::System.Data.DataColumn columnnm_usuario;
            
            private global::System.Data.DataColumn columnsg_nivel;
            
            private global::System.Data.DataColumn columnnm_login;
            
            private global::System.Data.DataColumn columncd_senha;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioDataTable() {
                this.TableName = "tb_usuario";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_usuarioDataTable(global::System.Data.DataTable table) {
                this.TableName = table.TableName;
                if ((table.CaseSensitive != table.DataSet.CaseSensitive)) {
                    this.CaseSensitive = table.CaseSensitive;
                }
                if ((table.Locale.ToString() != table.DataSet.Locale.ToString())) {
                    this.Locale = table.Locale;
                }
                if ((table.Namespace != table.DataSet.Namespace)) {
                    this.Namespace = table.Namespace;
                }
                this.Prefix = table.Prefix;
                this.MinimumCapacity = table.MinimumCapacity;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected tb_usuarioDataTable(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) : 
                    base(info, context) {
                this.InitVars();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_usuarioColumn {
                get {
                    return this.columncd_usuario;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_usuarioColumn {
                get {
                    return this.columnnm_usuario;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn sg_nivelColumn {
                get {
                    return this.columnsg_nivel;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_loginColumn {
                get {
                    return this.columnnm_login;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_senhaColumn {
                get {
                    return this.columncd_senha;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            [global::System.ComponentModel.Browsable(false)]
            public int Count {
                get {
                    return this.Rows.Count;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioRow this[int index] {
                get {
                    return ((tb_usuarioRow)(this.Rows[index]));
                }
            }
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_usuarioRowChangeEventHandler tb_usuarioRowChanging;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_usuarioRowChangeEventHandler tb_usuarioRowChanged;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_usuarioRowChangeEventHandler tb_usuarioRowDeleting;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_usuarioRowChangeEventHandler tb_usuarioRowDeleted;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Addtb_usuarioRow(tb_usuarioRow row) {
                this.Rows.Add(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioRow Addtb_usuarioRow(string nm_usuario, string sg_nivel, string nm_login, string cd_senha) {
                tb_usuarioRow rowtb_usuarioRow = ((tb_usuarioRow)(this.NewRow()));
                object[] columnValuesArray = new object[] {
                        null,
                        nm_usuario,
                        sg_nivel,
                        nm_login,
                        cd_senha};
                rowtb_usuarioRow.ItemArray = columnValuesArray;
                this.Rows.Add(rowtb_usuarioRow);
                return rowtb_usuarioRow;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioRow FindBycd_usuario(int cd_usuario) {
                return ((tb_usuarioRow)(this.Rows.Find(new object[] {
                            cd_usuario})));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public override global::System.Data.DataTable Clone() {
                tb_usuarioDataTable cln = ((tb_usuarioDataTable)(base.Clone()));
                cln.InitVars();
                return cln;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataTable CreateInstance() {
                return new tb_usuarioDataTable();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal void InitVars() {
                this.columncd_usuario = base.Columns["cd_usuario"];
                this.columnnm_usuario = base.Columns["nm_usuario"];
                this.columnsg_nivel = base.Columns["sg_nivel"];
                this.columnnm_login = base.Columns["nm_login"];
                this.columncd_senha = base.Columns["cd_senha"];
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            private void InitClass() {
                this.columncd_usuario = new global::System.Data.DataColumn("cd_usuario", typeof(int), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_usuario);
                this.columnnm_usuario = new global::System.Data.DataColumn("nm_usuario", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_usuario);
                this.columnsg_nivel = new global::System.Data.DataColumn("sg_nivel", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnsg_nivel);
                this.columnnm_login = new global::System.Data.DataColumn("nm_login", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_login);
                this.columncd_senha = new global::System.Data.DataColumn("cd_senha", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_senha);
                this.Constraints.Add(new global::System.Data.UniqueConstraint("Constraint1", new global::System.Data.DataColumn[] {
                                this.columncd_usuario}, true));
                this.columncd_usuario.AutoIncrement = true;
                this.columncd_usuario.AutoIncrementSeed = -1;
                this.columncd_usuario.AutoIncrementStep = -1;
                this.columncd_usuario.AllowDBNull = false;
                this.columncd_usuario.ReadOnly = true;
                this.columncd_usuario.Unique = true;
                this.columnnm_usuario.MaxLength = 100;
                this.columnsg_nivel.MaxLength = 1;
                this.columnnm_login.MaxLength = 15;
                this.columncd_senha.MaxLength = 15;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioRow Newtb_usuarioRow() {
                return ((tb_usuarioRow)(this.NewRow()));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataRow NewRowFromBuilder(global::System.Data.DataRowBuilder builder) {
                return new tb_usuarioRow(builder);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Type GetRowType() {
                return typeof(tb_usuarioRow);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanged(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanged(e);
                if ((this.tb_usuarioRowChanged != null)) {
                    this.tb_usuarioRowChanged(this, new tb_usuarioRowChangeEvent(((tb_usuarioRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanging(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanging(e);
                if ((this.tb_usuarioRowChanging != null)) {
                    this.tb_usuarioRowChanging(this, new tb_usuarioRowChangeEvent(((tb_usuarioRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleted(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleted(e);
                if ((this.tb_usuarioRowDeleted != null)) {
                    this.tb_usuarioRowDeleted(this, new tb_usuarioRowChangeEvent(((tb_usuarioRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleting(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleting(e);
                if ((this.tb_usuarioRowDeleting != null)) {
                    this.tb_usuarioRowDeleting(this, new tb_usuarioRowChangeEvent(((tb_usuarioRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Removetb_usuarioRow(tb_usuarioRow row) {
                this.Rows.Remove(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public static global::System.Xml.Schema.XmlSchemaComplexType GetTypedTableSchema(global::System.Xml.Schema.XmlSchemaSet xs) {
                global::System.Xml.Schema.XmlSchemaComplexType type = new global::System.Xml.Schema.XmlSchemaComplexType();
                global::System.Xml.Schema.XmlSchemaSequence sequence = new global::System.Xml.Schema.XmlSchemaSequence();
                bancoDataSet1 ds = new bancoDataSet1();
                global::System.Xml.Schema.XmlSchemaAny any1 = new global::System.Xml.Schema.XmlSchemaAny();
                any1.Namespace = "http://www.w3.org/2001/XMLSchema";
                any1.MinOccurs = new decimal(0);
                any1.MaxOccurs = decimal.MaxValue;
                any1.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any1);
                global::System.Xml.Schema.XmlSchemaAny any2 = new global::System.Xml.Schema.XmlSchemaAny();
                any2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
                any2.MinOccurs = new decimal(1);
                any2.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any2);
                global::System.Xml.Schema.XmlSchemaAttribute attribute1 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute1.Name = "namespace";
                attribute1.FixedValue = ds.Namespace;
                type.Attributes.Add(attribute1);
                global::System.Xml.Schema.XmlSchemaAttribute attribute2 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute2.Name = "tableTypeName";
                attribute2.FixedValue = "tb_usuarioDataTable";
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                global::System.Xml.Schema.XmlSchema dsSchema = ds.GetSchemaSerializable();
                if (xs.Contains(dsSchema.TargetNamespace)) {
                    global::System.IO.MemoryStream s1 = new global::System.IO.MemoryStream();
                    global::System.IO.MemoryStream s2 = new global::System.IO.MemoryStream();
                    try {
                        global::System.Xml.Schema.XmlSchema schema = null;
                        dsSchema.Write(s1);
                        for (global::System.Collections.IEnumerator schemas = xs.Schemas(dsSchema.TargetNamespace).GetEnumerator(); schemas.MoveNext(); ) {
                            schema = ((global::System.Xml.Schema.XmlSchema)(schemas.Current));
                            s2.SetLength(0);
                            schema.Write(s2);
                            if ((s1.Length == s2.Length)) {
                                s1.Position = 0;
                                s2.Position = 0;
                                for (; ((s1.Position != s1.Length) 
                                            && (s1.ReadByte() == s2.ReadByte())); ) {
                                    ;
                                }
                                if ((s1.Position == s1.Length)) {
                                    return type;
                                }
                            }
                        }
                    }
                    finally {
                        if ((s1 != null)) {
                            s1.Close();
                        }
                        if ((s2 != null)) {
                            s2.Close();
                        }
                    }
                }
                xs.Add(dsSchema);
                return type;
            }
        }
        
        [global::System.Serializable()]
        [global::System.Xml.Serialization.XmlSchemaProviderAttribute("GetTypedTableSchema")]
        public partial class tb_produtosDataTable : global::System.Data.TypedTableBase<tb_produtosRow> {
            
            private global::System.Data.DataColumn columncd_produto;
            
            private global::System.Data.DataColumn columnnm_produto;
            
            private global::System.Data.DataColumn columnsg_unidade_venda_produto;
            
            private global::System.Data.DataColumn columnvl_custo;
            
            private global::System.Data.DataColumn columnvl_venda;
            
            private global::System.Data.DataColumn columnqt_estoque;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosDataTable() {
                this.TableName = "tb_produtos";
                this.BeginInit();
                this.InitClass();
                this.EndInit();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_produtosDataTable(global::System.Data.DataTable table) {
                this.TableName = table.TableName;
                if ((table.CaseSensitive != table.DataSet.CaseSensitive)) {
                    this.CaseSensitive = table.CaseSensitive;
                }
                if ((table.Locale.ToString() != table.DataSet.Locale.ToString())) {
                    this.Locale = table.Locale;
                }
                if ((table.Namespace != table.DataSet.Namespace)) {
                    this.Namespace = table.Namespace;
                }
                this.Prefix = table.Prefix;
                this.MinimumCapacity = table.MinimumCapacity;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected tb_produtosDataTable(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) : 
                    base(info, context) {
                this.InitVars();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn cd_produtoColumn {
                get {
                    return this.columncd_produto;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn nm_produtoColumn {
                get {
                    return this.columnnm_produto;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn sg_unidade_venda_produtoColumn {
                get {
                    return this.columnsg_unidade_venda_produto;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn vl_custoColumn {
                get {
                    return this.columnvl_custo;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn vl_vendaColumn {
                get {
                    return this.columnvl_venda;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataColumn qt_estoqueColumn {
                get {
                    return this.columnqt_estoque;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            [global::System.ComponentModel.Browsable(false)]
            public int Count {
                get {
                    return this.Rows.Count;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosRow this[int index] {
                get {
                    return ((tb_produtosRow)(this.Rows[index]));
                }
            }
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_produtosRowChangeEventHandler tb_produtosRowChanging;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_produtosRowChangeEventHandler tb_produtosRowChanged;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_produtosRowChangeEventHandler tb_produtosRowDeleting;
            
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public event tb_produtosRowChangeEventHandler tb_produtosRowDeleted;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Addtb_produtosRow(tb_produtosRow row) {
                this.Rows.Add(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosRow Addtb_produtosRow(string nm_produto, string sg_unidade_venda_produto, decimal vl_custo, decimal vl_venda, int qt_estoque) {
                tb_produtosRow rowtb_produtosRow = ((tb_produtosRow)(this.NewRow()));
                object[] columnValuesArray = new object[] {
                        null,
                        nm_produto,
                        sg_unidade_venda_produto,
                        vl_custo,
                        vl_venda,
                        qt_estoque};
                rowtb_produtosRow.ItemArray = columnValuesArray;
                this.Rows.Add(rowtb_produtosRow);
                return rowtb_produtosRow;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosRow FindBycd_produto(int cd_produto) {
                return ((tb_produtosRow)(this.Rows.Find(new object[] {
                            cd_produto})));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public override global::System.Data.DataTable Clone() {
                tb_produtosDataTable cln = ((tb_produtosDataTable)(base.Clone()));
                cln.InitVars();
                return cln;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataTable CreateInstance() {
                return new tb_produtosDataTable();
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal void InitVars() {
                this.columncd_produto = base.Columns["cd_produto"];
                this.columnnm_produto = base.Columns["nm_produto"];
                this.columnsg_unidade_venda_produto = base.Columns["sg_unidade_venda_produto"];
                this.columnvl_custo = base.Columns["vl_custo"];
                this.columnvl_venda = base.Columns["vl_venda"];
                this.columnqt_estoque = base.Columns["qt_estoque"];
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            private void InitClass() {
                this.columncd_produto = new global::System.Data.DataColumn("cd_produto", typeof(int), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columncd_produto);
                this.columnnm_produto = new global::System.Data.DataColumn("nm_produto", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnnm_produto);
                this.columnsg_unidade_venda_produto = new global::System.Data.DataColumn("sg_unidade_venda_produto", typeof(string), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnsg_unidade_venda_produto);
                this.columnvl_custo = new global::System.Data.DataColumn("vl_custo", typeof(decimal), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnvl_custo);
                this.columnvl_venda = new global::System.Data.DataColumn("vl_venda", typeof(decimal), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnvl_venda);
                this.columnqt_estoque = new global::System.Data.DataColumn("qt_estoque", typeof(int), null, global::System.Data.MappingType.Element);
                base.Columns.Add(this.columnqt_estoque);
                this.Constraints.Add(new global::System.Data.UniqueConstraint("Constraint1", new global::System.Data.DataColumn[] {
                                this.columncd_produto}, true));
                this.columncd_produto.AutoIncrement = true;
                this.columncd_produto.AutoIncrementSeed = -1;
                this.columncd_produto.AutoIncrementStep = -1;
                this.columncd_produto.AllowDBNull = false;
                this.columncd_produto.ReadOnly = true;
                this.columncd_produto.Unique = true;
                this.columnnm_produto.MaxLength = 50;
                this.columnsg_unidade_venda_produto.MaxLength = 2;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosRow Newtb_produtosRow() {
                return ((tb_produtosRow)(this.NewRow()));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Data.DataRow NewRowFromBuilder(global::System.Data.DataRowBuilder builder) {
                return new tb_produtosRow(builder);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override global::System.Type GetRowType() {
                return typeof(tb_produtosRow);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanged(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanged(e);
                if ((this.tb_produtosRowChanged != null)) {
                    this.tb_produtosRowChanged(this, new tb_produtosRowChangeEvent(((tb_produtosRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowChanging(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowChanging(e);
                if ((this.tb_produtosRowChanging != null)) {
                    this.tb_produtosRowChanging(this, new tb_produtosRowChangeEvent(((tb_produtosRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleted(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleted(e);
                if ((this.tb_produtosRowDeleted != null)) {
                    this.tb_produtosRowDeleted(this, new tb_produtosRowChangeEvent(((tb_produtosRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            protected override void OnRowDeleting(global::System.Data.DataRowChangeEventArgs e) {
                base.OnRowDeleting(e);
                if ((this.tb_produtosRowDeleting != null)) {
                    this.tb_produtosRowDeleting(this, new tb_produtosRowChangeEvent(((tb_produtosRow)(e.Row)), e.Action));
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Removetb_produtosRow(tb_produtosRow row) {
                this.Rows.Remove(row);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public static global::System.Xml.Schema.XmlSchemaComplexType GetTypedTableSchema(global::System.Xml.Schema.XmlSchemaSet xs) {
                global::System.Xml.Schema.XmlSchemaComplexType type = new global::System.Xml.Schema.XmlSchemaComplexType();
                global::System.Xml.Schema.XmlSchemaSequence sequence = new global::System.Xml.Schema.XmlSchemaSequence();
                bancoDataSet1 ds = new bancoDataSet1();
                global::System.Xml.Schema.XmlSchemaAny any1 = new global::System.Xml.Schema.XmlSchemaAny();
                any1.Namespace = "http://www.w3.org/2001/XMLSchema";
                any1.MinOccurs = new decimal(0);
                any1.MaxOccurs = decimal.MaxValue;
                any1.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any1);
                global::System.Xml.Schema.XmlSchemaAny any2 = new global::System.Xml.Schema.XmlSchemaAny();
                any2.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
                any2.MinOccurs = new decimal(1);
                any2.ProcessContents = global::System.Xml.Schema.XmlSchemaContentProcessing.Lax;
                sequence.Items.Add(any2);
                global::System.Xml.Schema.XmlSchemaAttribute attribute1 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute1.Name = "namespace";
                attribute1.FixedValue = ds.Namespace;
                type.Attributes.Add(attribute1);
                global::System.Xml.Schema.XmlSchemaAttribute attribute2 = new global::System.Xml.Schema.XmlSchemaAttribute();
                attribute2.Name = "tableTypeName";
                attribute2.FixedValue = "tb_produtosDataTable";
                type.Attributes.Add(attribute2);
                type.Particle = sequence;
                global::System.Xml.Schema.XmlSchema dsSchema = ds.GetSchemaSerializable();
                if (xs.Contains(dsSchema.TargetNamespace)) {
                    global::System.IO.MemoryStream s1 = new global::System.IO.MemoryStream();
                    global::System.IO.MemoryStream s2 = new global::System.IO.MemoryStream();
                    try {
                        global::System.Xml.Schema.XmlSchema schema = null;
                        dsSchema.Write(s1);
                        for (global::System.Collections.IEnumerator schemas = xs.Schemas(dsSchema.TargetNamespace).GetEnumerator(); schemas.MoveNext(); ) {
                            schema = ((global::System.Xml.Schema.XmlSchema)(schemas.Current));
                            s2.SetLength(0);
                            schema.Write(s2);
                            if ((s1.Length == s2.Length)) {
                                s1.Position = 0;
                                s2.Position = 0;
                                for (; ((s1.Position != s1.Length) 
                                            && (s1.ReadByte() == s2.ReadByte())); ) {
                                    ;
                                }
                                if ((s1.Position == s1.Length)) {
                                    return type;
                                }
                            }
                        }
                    }
                    finally {
                        if ((s1 != null)) {
                            s1.Close();
                        }
                        if ((s2 != null)) {
                            s2.Close();
                        }
                    }
                }
                xs.Add(dsSchema);
                return type;
            }
        }
        
        public partial class tb_clienteRow : global::System.Data.DataRow {
            
            private tb_clienteDataTable tabletb_cliente;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_clienteRow(global::System.Data.DataRowBuilder rb) : 
                    base(rb) {
                this.tabletb_cliente = ((tb_clienteDataTable)(this.Table));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public int cd_cliente {
                get {
                    return ((int)(this[this.tabletb_cliente.cd_clienteColumn]));
                }
                set {
                    this[this.tabletb_cliente.cd_clienteColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_cliente {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.nm_clienteColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_cliente\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.nm_clienteColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string ds_endereco {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.ds_enderecoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'ds_endereco\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.ds_enderecoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_bairro {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.nm_bairroColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_bairro\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.nm_bairroColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_cidade {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.nm_cidadeColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_cidade\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.nm_cidadeColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string sg_estado {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.sg_estadoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'sg_estado\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.sg_estadoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_cep {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.cd_cepColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_cep\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.cd_cepColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_cpf {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.cd_cpfColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_cpf\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.cd_cpfColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_rg {
                get {
                    try {
                        return ((string)(this[this.tabletb_cliente.cd_rgColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_rg\' na tabela \'tb_cliente\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_cliente.cd_rgColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_clienteNull() {
                return this.IsNull(this.tabletb_cliente.nm_clienteColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_clienteNull() {
                this[this.tabletb_cliente.nm_clienteColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isds_enderecoNull() {
                return this.IsNull(this.tabletb_cliente.ds_enderecoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setds_enderecoNull() {
                this[this.tabletb_cliente.ds_enderecoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_bairroNull() {
                return this.IsNull(this.tabletb_cliente.nm_bairroColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_bairroNull() {
                this[this.tabletb_cliente.nm_bairroColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_cidadeNull() {
                return this.IsNull(this.tabletb_cliente.nm_cidadeColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_cidadeNull() {
                this[this.tabletb_cliente.nm_cidadeColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Issg_estadoNull() {
                return this.IsNull(this.tabletb_cliente.sg_estadoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setsg_estadoNull() {
                this[this.tabletb_cliente.sg_estadoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_cepNull() {
                return this.IsNull(this.tabletb_cliente.cd_cepColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_cepNull() {
                this[this.tabletb_cliente.cd_cepColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_cpfNull() {
                return this.IsNull(this.tabletb_cliente.cd_cpfColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_cpfNull() {
                this[this.tabletb_cliente.cd_cpfColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_rgNull() {
                return this.IsNull(this.tabletb_cliente.cd_rgColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_rgNull() {
                this[this.tabletb_cliente.cd_rgColumn] = global::System.Convert.DBNull;
            }
        }
        
        public partial class tb_fornecedorRow : global::System.Data.DataRow {
            
            private tb_fornecedorDataTable tabletb_fornecedor;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_fornecedorRow(global::System.Data.DataRowBuilder rb) : 
                    base(rb) {
                this.tabletb_fornecedor = ((tb_fornecedorDataTable)(this.Table));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public int cd_fornecedor {
                get {
                    return ((int)(this[this.tabletb_fornecedor.cd_fornecedorColumn]));
                }
                set {
                    this[this.tabletb_fornecedor.cd_fornecedorColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_fornecedor {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.nm_fornecedorColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_fornecedor\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.nm_fornecedorColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string ds_endereco {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.ds_enderecoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'ds_endereco\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.ds_enderecoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_bairro {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.nm_bairroColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_bairro\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.nm_bairroColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_cidade {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.nm_cidadeColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_cidade\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.nm_cidadeColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string sg_estado {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.sg_estadoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'sg_estado\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.sg_estadoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_cep {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.cd_cepColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_cep\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.cd_cepColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_cnpj {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.cd_cnpjColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_cnpj\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.cd_cnpjColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_ie {
                get {
                    try {
                        return ((string)(this[this.tabletb_fornecedor.cd_ieColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_ie\' na tabela \'tb_fornecedor\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_fornecedor.cd_ieColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_fornecedorNull() {
                return this.IsNull(this.tabletb_fornecedor.nm_fornecedorColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_fornecedorNull() {
                this[this.tabletb_fornecedor.nm_fornecedorColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isds_enderecoNull() {
                return this.IsNull(this.tabletb_fornecedor.ds_enderecoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setds_enderecoNull() {
                this[this.tabletb_fornecedor.ds_enderecoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_bairroNull() {
                return this.IsNull(this.tabletb_fornecedor.nm_bairroColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_bairroNull() {
                this[this.tabletb_fornecedor.nm_bairroColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_cidadeNull() {
                return this.IsNull(this.tabletb_fornecedor.nm_cidadeColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_cidadeNull() {
                this[this.tabletb_fornecedor.nm_cidadeColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Issg_estadoNull() {
                return this.IsNull(this.tabletb_fornecedor.sg_estadoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setsg_estadoNull() {
                this[this.tabletb_fornecedor.sg_estadoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_cepNull() {
                return this.IsNull(this.tabletb_fornecedor.cd_cepColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_cepNull() {
                this[this.tabletb_fornecedor.cd_cepColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_cnpjNull() {
                return this.IsNull(this.tabletb_fornecedor.cd_cnpjColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_cnpjNull() {
                this[this.tabletb_fornecedor.cd_cnpjColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_ieNull() {
                return this.IsNull(this.tabletb_fornecedor.cd_ieColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_ieNull() {
                this[this.tabletb_fornecedor.cd_ieColumn] = global::System.Convert.DBNull;
            }
        }
        
        public partial class tb_usuarioRow : global::System.Data.DataRow {
            
            private tb_usuarioDataTable tabletb_usuario;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_usuarioRow(global::System.Data.DataRowBuilder rb) : 
                    base(rb) {
                this.tabletb_usuario = ((tb_usuarioDataTable)(this.Table));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public int cd_usuario {
                get {
                    return ((int)(this[this.tabletb_usuario.cd_usuarioColumn]));
                }
                set {
                    this[this.tabletb_usuario.cd_usuarioColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_usuario {
                get {
                    try {
                        return ((string)(this[this.tabletb_usuario.nm_usuarioColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_usuario\' na tabela \'tb_usuario\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_usuario.nm_usuarioColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string sg_nivel {
                get {
                    try {
                        return ((string)(this[this.tabletb_usuario.sg_nivelColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'sg_nivel\' na tabela \'tb_usuario\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_usuario.sg_nivelColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_login {
                get {
                    try {
                        return ((string)(this[this.tabletb_usuario.nm_loginColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_login\' na tabela \'tb_usuario\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_usuario.nm_loginColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string cd_senha {
                get {
                    try {
                        return ((string)(this[this.tabletb_usuario.cd_senhaColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'cd_senha\' na tabela \'tb_usuario\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_usuario.cd_senhaColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_usuarioNull() {
                return this.IsNull(this.tabletb_usuario.nm_usuarioColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_usuarioNull() {
                this[this.tabletb_usuario.nm_usuarioColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Issg_nivelNull() {
                return this.IsNull(this.tabletb_usuario.sg_nivelColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setsg_nivelNull() {
                this[this.tabletb_usuario.sg_nivelColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_loginNull() {
                return this.IsNull(this.tabletb_usuario.nm_loginColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_loginNull() {
                this[this.tabletb_usuario.nm_loginColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Iscd_senhaNull() {
                return this.IsNull(this.tabletb_usuario.cd_senhaColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setcd_senhaNull() {
                this[this.tabletb_usuario.cd_senhaColumn] = global::System.Convert.DBNull;
            }
        }
        
        public partial class tb_produtosRow : global::System.Data.DataRow {
            
            private tb_produtosDataTable tabletb_produtos;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal tb_produtosRow(global::System.Data.DataRowBuilder rb) : 
                    base(rb) {
                this.tabletb_produtos = ((tb_produtosDataTable)(this.Table));
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public int cd_produto {
                get {
                    return ((int)(this[this.tabletb_produtos.cd_produtoColumn]));
                }
                set {
                    this[this.tabletb_produtos.cd_produtoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string nm_produto {
                get {
                    try {
                        return ((string)(this[this.tabletb_produtos.nm_produtoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'nm_produto\' na tabela \'tb_produtos\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_produtos.nm_produtoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public string sg_unidade_venda_produto {
                get {
                    try {
                        return ((string)(this[this.tabletb_produtos.sg_unidade_venda_produtoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'sg_unidade_venda_produto\' na tabela \'tb_produtos\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_produtos.sg_unidade_venda_produtoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public decimal vl_custo {
                get {
                    try {
                        return ((decimal)(this[this.tabletb_produtos.vl_custoColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'vl_custo\' na tabela \'tb_produtos\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_produtos.vl_custoColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public decimal vl_venda {
                get {
                    try {
                        return ((decimal)(this[this.tabletb_produtos.vl_vendaColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'vl_venda\' na tabela \'tb_produtos\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_produtos.vl_vendaColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public int qt_estoque {
                get {
                    try {
                        return ((int)(this[this.tabletb_produtos.qt_estoqueColumn]));
                    }
                    catch (global::System.InvalidCastException e) {
                        throw new global::System.Data.StrongTypingException("O valor da coluna \'qt_estoque\' na tabela \'tb_produtos\' é DBNull.", e);
                    }
                }
                set {
                    this[this.tabletb_produtos.qt_estoqueColumn] = value;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isnm_produtoNull() {
                return this.IsNull(this.tabletb_produtos.nm_produtoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setnm_produtoNull() {
                this[this.tabletb_produtos.nm_produtoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Issg_unidade_venda_produtoNull() {
                return this.IsNull(this.tabletb_produtos.sg_unidade_venda_produtoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setsg_unidade_venda_produtoNull() {
                this[this.tabletb_produtos.sg_unidade_venda_produtoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isvl_custoNull() {
                return this.IsNull(this.tabletb_produtos.vl_custoColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setvl_custoNull() {
                this[this.tabletb_produtos.vl_custoColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isvl_vendaNull() {
                return this.IsNull(this.tabletb_produtos.vl_vendaColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setvl_vendaNull() {
                this[this.tabletb_produtos.vl_vendaColumn] = global::System.Convert.DBNull;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public bool Isqt_estoqueNull() {
                return this.IsNull(this.tabletb_produtos.qt_estoqueColumn);
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public void Setqt_estoqueNull() {
                this[this.tabletb_produtos.qt_estoqueColumn] = global::System.Convert.DBNull;
            }
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public class tb_clienteRowChangeEvent : global::System.EventArgs {
            
            private tb_clienteRow eventRow;
            
            private global::System.Data.DataRowAction eventAction;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteRowChangeEvent(tb_clienteRow row, global::System.Data.DataRowAction action) {
                this.eventRow = row;
                this.eventAction = action;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_clienteRow Row {
                get {
                    return this.eventRow;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataRowAction Action {
                get {
                    return this.eventAction;
                }
            }
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public class tb_fornecedorRowChangeEvent : global::System.EventArgs {
            
            private tb_fornecedorRow eventRow;
            
            private global::System.Data.DataRowAction eventAction;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorRowChangeEvent(tb_fornecedorRow row, global::System.Data.DataRowAction action) {
                this.eventRow = row;
                this.eventAction = action;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_fornecedorRow Row {
                get {
                    return this.eventRow;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataRowAction Action {
                get {
                    return this.eventAction;
                }
            }
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public class tb_usuarioRowChangeEvent : global::System.EventArgs {
            
            private tb_usuarioRow eventRow;
            
            private global::System.Data.DataRowAction eventAction;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioRowChangeEvent(tb_usuarioRow row, global::System.Data.DataRowAction action) {
                this.eventRow = row;
                this.eventAction = action;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_usuarioRow Row {
                get {
                    return this.eventRow;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataRowAction Action {
                get {
                    return this.eventAction;
                }
            }
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public class tb_produtosRowChangeEvent : global::System.EventArgs {
            
            private tb_produtosRow eventRow;
            
            private global::System.Data.DataRowAction eventAction;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosRowChangeEvent(tb_produtosRow row, global::System.Data.DataRowAction action) {
                this.eventRow = row;
                this.eventAction = action;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public tb_produtosRow Row {
                get {
                    return this.eventRow;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public global::System.Data.DataRowAction Action {
                get {
                    return this.eventAction;
                }
            }
        }
    }
}
namespace ProjetoEstoque.bancoDataSet1TableAdapters {
    
    
    [global::System.ComponentModel.DesignerCategoryAttribute("code")]
    [global::System.ComponentModel.ToolboxItem(true)]
    [global::System.ComponentModel.DataObjectAttribute(true)]
    [global::System.ComponentModel.DesignerAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner" +
        ", Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
    public partial class tb_clienteTableAdapter : global::System.ComponentModel.Component {
        
        private global::System.Data.SqlClient.SqlDataAdapter _adapter;
        
        private global::System.Data.SqlClient.SqlConnection _connection;
        
        private global::System.Data.SqlClient.SqlTransaction _transaction;
        
        private global::System.Data.SqlClient.SqlCommand[] _commandCollection;
        
        private bool _clearBeforeFill;
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public tb_clienteTableAdapter() {
            this.ClearBeforeFill = true;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected internal global::System.Data.SqlClient.SqlDataAdapter Adapter {
            get {
                if ((this._adapter == null)) {
                    this.InitAdapter();
                }
                return this._adapter;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlConnection Connection {
            get {
                if ((this._connection == null)) {
                    this.InitConnection();
                }
                return this._connection;
            }
            set {
                this._connection = value;
                if ((this.Adapter.InsertCommand != null)) {
                    this.Adapter.InsertCommand.Connection = value;
                }
                if ((this.Adapter.DeleteCommand != null)) {
                    this.Adapter.DeleteCommand.Connection = value;
                }
                if ((this.Adapter.UpdateCommand != null)) {
                    this.Adapter.UpdateCommand.Connection = value;
                }
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    if ((this.CommandCollection[i] != null)) {
                        ((global::System.Data.SqlClient.SqlCommand)(this.CommandCollection[i])).Connection = value;
                    }
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlTransaction Transaction {
            get {
                return this._transaction;
            }
            set {
                this._transaction = value;
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    this.CommandCollection[i].Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.DeleteCommand != null))) {
                    this.Adapter.DeleteCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.InsertCommand != null))) {
                    this.Adapter.InsertCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.UpdateCommand != null))) {
                    this.Adapter.UpdateCommand.Transaction = this._transaction;
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected global::System.Data.SqlClient.SqlCommand[] CommandCollection {
            get {
                if ((this._commandCollection == null)) {
                    this.InitCommandCollection();
                }
                return this._commandCollection;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public bool ClearBeforeFill {
            get {
                return this._clearBeforeFill;
            }
            set {
                this._clearBeforeFill = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitAdapter() {
            this._adapter = new global::System.Data.SqlClient.SqlDataAdapter();
            global::System.Data.Common.DataTableMapping tableMapping = new global::System.Data.Common.DataTableMapping();
            tableMapping.SourceTable = "Table";
            tableMapping.DataSetTable = "tb_cliente";
            tableMapping.ColumnMappings.Add("cd_cliente", "cd_cliente");
            tableMapping.ColumnMappings.Add("nm_cliente", "nm_cliente");
            tableMapping.ColumnMappings.Add("ds_endereco", "ds_endereco");
            tableMapping.ColumnMappings.Add("nm_bairro", "nm_bairro");
            tableMapping.ColumnMappings.Add("nm_cidade", "nm_cidade");
            tableMapping.ColumnMappings.Add("sg_estado", "sg_estado");
            tableMapping.ColumnMappings.Add("cd_cep", "cd_cep");
            tableMapping.ColumnMappings.Add("cd_cpf", "cd_cpf");
            tableMapping.ColumnMappings.Add("cd_rg", "cd_rg");
            this._adapter.TableMappings.Add(tableMapping);
            this._adapter.DeleteCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.DeleteCommand.Connection = this.Connection;
            this._adapter.DeleteCommand.CommandText = @"DELETE FROM [tb_cliente] WHERE (([cd_cliente] = @Original_cd_cliente) AND ((@IsNull_nm_cliente = 1 AND [nm_cliente] IS NULL) OR ([nm_cliente] = @Original_nm_cliente)) AND ((@IsNull_ds_endereco = 1 AND [ds_endereco] IS NULL) OR ([ds_endereco] = @Original_ds_endereco)) AND ((@IsNull_nm_bairro = 1 AND [nm_bairro] IS NULL) OR ([nm_bairro] = @Original_nm_bairro)) AND ((@IsNull_nm_cidade = 1 AND [nm_cidade] IS NULL) OR ([nm_cidade] = @Original_nm_cidade)) AND ((@IsNull_sg_estado = 1 AND [sg_estado] IS NULL) OR ([sg_estado] = @Original_sg_estado)) AND ((@IsNull_cd_cep = 1 AND [cd_cep] IS NULL) OR ([cd_cep] = @Original_cd_cep)) AND ((@IsNull_cd_cpf = 1 AND [cd_cpf] IS NULL) OR ([cd_cpf] = @Original_cd_cpf)) AND ((@IsNull_cd_rg = 1 AND [cd_rg] IS NULL) OR ([cd_rg] = @Original_cd_rg)))";
            this._adapter.DeleteCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cliente", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cliente", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_cliente", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cliente", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_cliente", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cliente", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_ds_endereco", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_bairro", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_cidade", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_estado", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cep", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cpf", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cpf", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cpf", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cpf", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_rg", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_rg", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_rg", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_rg", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.InsertCommand.Connection = this.Connection;
            this._adapter.InsertCommand.CommandText = @"INSERT INTO [tb_cliente] ([nm_cliente], [ds_endereco], [nm_bairro], [nm_cidade], [sg_estado], [cd_cep], [cd_cpf], [cd_rg]) VALUES (@nm_cliente, @ds_endereco, @nm_bairro, @nm_cidade, @sg_estado, @cd_cep, @cd_cpf, @cd_rg);
SELECT cd_cliente, nm_cliente, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_cep, cd_cpf, cd_rg FROM tb_cliente WHERE (cd_cliente = SCOPE_IDENTITY())";
            this._adapter.InsertCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_cliente", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cliente", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cpf", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cpf", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_rg", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_rg", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.UpdateCommand.Connection = this.Connection;
            this._adapter.UpdateCommand.CommandText = @"UPDATE [tb_cliente] SET [nm_cliente] = @nm_cliente, [ds_endereco] = @ds_endereco, [nm_bairro] = @nm_bairro, [nm_cidade] = @nm_cidade, [sg_estado] = @sg_estado, [cd_cep] = @cd_cep, [cd_cpf] = @cd_cpf, [cd_rg] = @cd_rg WHERE (([cd_cliente] = @Original_cd_cliente) AND ((@IsNull_nm_cliente = 1 AND [nm_cliente] IS NULL) OR ([nm_cliente] = @Original_nm_cliente)) AND ((@IsNull_ds_endereco = 1 AND [ds_endereco] IS NULL) OR ([ds_endereco] = @Original_ds_endereco)) AND ((@IsNull_nm_bairro = 1 AND [nm_bairro] IS NULL) OR ([nm_bairro] = @Original_nm_bairro)) AND ((@IsNull_nm_cidade = 1 AND [nm_cidade] IS NULL) OR ([nm_cidade] = @Original_nm_cidade)) AND ((@IsNull_sg_estado = 1 AND [sg_estado] IS NULL) OR ([sg_estado] = @Original_sg_estado)) AND ((@IsNull_cd_cep = 1 AND [cd_cep] IS NULL) OR ([cd_cep] = @Original_cd_cep)) AND ((@IsNull_cd_cpf = 1 AND [cd_cpf] IS NULL) OR ([cd_cpf] = @Original_cd_cpf)) AND ((@IsNull_cd_rg = 1 AND [cd_rg] IS NULL) OR ([cd_rg] = @Original_cd_rg)));
SELECT cd_cliente, nm_cliente, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_cep, cd_cpf, cd_rg FROM tb_cliente WHERE (cd_cliente = @cd_cliente)";
            this._adapter.UpdateCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_cliente", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cliente", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cpf", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cpf", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_rg", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_rg", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cliente", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cliente", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_cliente", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cliente", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_cliente", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cliente", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_ds_endereco", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_bairro", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_cidade", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_estado", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cep", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cpf", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cpf", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cpf", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cpf", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_rg", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_rg", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_rg", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_rg", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cliente", global::System.Data.SqlDbType.Int, 4, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cliente", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitConnection() {
            this._connection = new global::System.Data.SqlClient.SqlConnection();
            this._connection.ConnectionString = global::ProjetoEstoque.Properties.Settings.Default.bancoConnectionString;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitCommandCollection() {
            this._commandCollection = new global::System.Data.SqlClient.SqlCommand[1];
            this._commandCollection[0] = new global::System.Data.SqlClient.SqlCommand();
            this._commandCollection[0].Connection = this.Connection;
            this._commandCollection[0].CommandText = "SELECT cd_cliente, nm_cliente, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_c" +
                "ep, cd_cpf, cd_rg FROM tb_cliente";
            this._commandCollection[0].CommandType = global::System.Data.CommandType.Text;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Fill, true)]
        public virtual int Fill(bancoDataSet1.tb_clienteDataTable dataTable) {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            if ((this.ClearBeforeFill == true)) {
                dataTable.Clear();
            }
            int returnValue = this.Adapter.Fill(dataTable);
            return returnValue;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Select, true)]
        public virtual bancoDataSet1.tb_clienteDataTable GetData() {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            bancoDataSet1.tb_clienteDataTable dataTable = new bancoDataSet1.tb_clienteDataTable();
            this.Adapter.Fill(dataTable);
            return dataTable;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1.tb_clienteDataTable dataTable) {
            return this.Adapter.Update(dataTable);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1 dataSet) {
            return this.Adapter.Update(dataSet, "tb_cliente");
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow dataRow) {
            return this.Adapter.Update(new global::System.Data.DataRow[] {
                        dataRow});
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow[] dataRows) {
            return this.Adapter.Update(dataRows);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Delete, true)]
        public virtual int Delete(int Original_cd_cliente, string Original_nm_cliente, string Original_ds_endereco, string Original_nm_bairro, string Original_nm_cidade, string Original_sg_estado, string Original_cd_cep, string Original_cd_cpf, string Original_cd_rg) {
            this.Adapter.DeleteCommand.Parameters[0].Value = ((int)(Original_cd_cliente));
            if ((Original_nm_cliente == null)) {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[2].Value = ((string)(Original_nm_cliente));
            }
            if ((Original_ds_endereco == null)) {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[4].Value = ((string)(Original_ds_endereco));
            }
            if ((Original_nm_bairro == null)) {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[6].Value = ((string)(Original_nm_bairro));
            }
            if ((Original_nm_cidade == null)) {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[8].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[8].Value = ((string)(Original_nm_cidade));
            }
            if ((Original_sg_estado == null)) {
                this.Adapter.DeleteCommand.Parameters[9].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[10].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[9].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[10].Value = ((string)(Original_sg_estado));
            }
            if ((Original_cd_cep == null)) {
                this.Adapter.DeleteCommand.Parameters[11].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[12].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[11].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[12].Value = ((string)(Original_cd_cep));
            }
            if ((Original_cd_cpf == null)) {
                this.Adapter.DeleteCommand.Parameters[13].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[14].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[13].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[14].Value = ((string)(Original_cd_cpf));
            }
            if ((Original_cd_rg == null)) {
                this.Adapter.DeleteCommand.Parameters[15].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[16].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[15].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[16].Value = ((string)(Original_cd_rg));
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.DeleteCommand.Connection.State;
            if (((this.Adapter.DeleteCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.DeleteCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.DeleteCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.DeleteCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Insert, true)]
        public virtual int Insert(string nm_cliente, string ds_endereco, string nm_bairro, string nm_cidade, string sg_estado, string cd_cep, string cd_cpf, string cd_rg) {
            if ((nm_cliente == null)) {
                this.Adapter.InsertCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[0].Value = ((string)(nm_cliente));
            }
            if ((ds_endereco == null)) {
                this.Adapter.InsertCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[1].Value = ((string)(ds_endereco));
            }
            if ((nm_bairro == null)) {
                this.Adapter.InsertCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[2].Value = ((string)(nm_bairro));
            }
            if ((nm_cidade == null)) {
                this.Adapter.InsertCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[3].Value = ((string)(nm_cidade));
            }
            if ((sg_estado == null)) {
                this.Adapter.InsertCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[4].Value = ((string)(sg_estado));
            }
            if ((cd_cep == null)) {
                this.Adapter.InsertCommand.Parameters[5].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[5].Value = ((string)(cd_cep));
            }
            if ((cd_cpf == null)) {
                this.Adapter.InsertCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[6].Value = ((string)(cd_cpf));
            }
            if ((cd_rg == null)) {
                this.Adapter.InsertCommand.Parameters[7].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[7].Value = ((string)(cd_rg));
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.InsertCommand.Connection.State;
            if (((this.Adapter.InsertCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.InsertCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.InsertCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.InsertCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(
                    string nm_cliente, 
                    string ds_endereco, 
                    string nm_bairro, 
                    string nm_cidade, 
                    string sg_estado, 
                    string cd_cep, 
                    string cd_cpf, 
                    string cd_rg, 
                    int Original_cd_cliente, 
                    string Original_nm_cliente, 
                    string Original_ds_endereco, 
                    string Original_nm_bairro, 
                    string Original_nm_cidade, 
                    string Original_sg_estado, 
                    string Original_cd_cep, 
                    string Original_cd_cpf, 
                    string Original_cd_rg, 
                    int cd_cliente) {
            if ((nm_cliente == null)) {
                this.Adapter.UpdateCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[0].Value = ((string)(nm_cliente));
            }
            if ((ds_endereco == null)) {
                this.Adapter.UpdateCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[1].Value = ((string)(ds_endereco));
            }
            if ((nm_bairro == null)) {
                this.Adapter.UpdateCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[2].Value = ((string)(nm_bairro));
            }
            if ((nm_cidade == null)) {
                this.Adapter.UpdateCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[3].Value = ((string)(nm_cidade));
            }
            if ((sg_estado == null)) {
                this.Adapter.UpdateCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[4].Value = ((string)(sg_estado));
            }
            if ((cd_cep == null)) {
                this.Adapter.UpdateCommand.Parameters[5].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[5].Value = ((string)(cd_cep));
            }
            if ((cd_cpf == null)) {
                this.Adapter.UpdateCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[6].Value = ((string)(cd_cpf));
            }
            if ((cd_rg == null)) {
                this.Adapter.UpdateCommand.Parameters[7].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[7].Value = ((string)(cd_rg));
            }
            this.Adapter.UpdateCommand.Parameters[8].Value = ((int)(Original_cd_cliente));
            if ((Original_nm_cliente == null)) {
                this.Adapter.UpdateCommand.Parameters[9].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[10].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[9].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[10].Value = ((string)(Original_nm_cliente));
            }
            if ((Original_ds_endereco == null)) {
                this.Adapter.UpdateCommand.Parameters[11].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[12].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[11].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[12].Value = ((string)(Original_ds_endereco));
            }
            if ((Original_nm_bairro == null)) {
                this.Adapter.UpdateCommand.Parameters[13].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[14].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[13].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[14].Value = ((string)(Original_nm_bairro));
            }
            if ((Original_nm_cidade == null)) {
                this.Adapter.UpdateCommand.Parameters[15].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[16].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[15].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[16].Value = ((string)(Original_nm_cidade));
            }
            if ((Original_sg_estado == null)) {
                this.Adapter.UpdateCommand.Parameters[17].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[18].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[17].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[18].Value = ((string)(Original_sg_estado));
            }
            if ((Original_cd_cep == null)) {
                this.Adapter.UpdateCommand.Parameters[19].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[20].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[19].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[20].Value = ((string)(Original_cd_cep));
            }
            if ((Original_cd_cpf == null)) {
                this.Adapter.UpdateCommand.Parameters[21].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[22].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[21].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[22].Value = ((string)(Original_cd_cpf));
            }
            if ((Original_cd_rg == null)) {
                this.Adapter.UpdateCommand.Parameters[23].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[24].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[23].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[24].Value = ((string)(Original_cd_rg));
            }
            this.Adapter.UpdateCommand.Parameters[25].Value = ((int)(cd_cliente));
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.UpdateCommand.Connection.State;
            if (((this.Adapter.UpdateCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.UpdateCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.UpdateCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.UpdateCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(
                    string nm_cliente, 
                    string ds_endereco, 
                    string nm_bairro, 
                    string nm_cidade, 
                    string sg_estado, 
                    string cd_cep, 
                    string cd_cpf, 
                    string cd_rg, 
                    int Original_cd_cliente, 
                    string Original_nm_cliente, 
                    string Original_ds_endereco, 
                    string Original_nm_bairro, 
                    string Original_nm_cidade, 
                    string Original_sg_estado, 
                    string Original_cd_cep, 
                    string Original_cd_cpf, 
                    string Original_cd_rg) {
            return this.Update(nm_cliente, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_cep, cd_cpf, cd_rg, Original_cd_cliente, Original_nm_cliente, Original_ds_endereco, Original_nm_bairro, Original_nm_cidade, Original_sg_estado, Original_cd_cep, Original_cd_cpf, Original_cd_rg, Original_cd_cliente);
        }
    }
    
    [global::System.ComponentModel.DesignerCategoryAttribute("code")]
    [global::System.ComponentModel.ToolboxItem(true)]
    [global::System.ComponentModel.DataObjectAttribute(true)]
    [global::System.ComponentModel.DesignerAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner" +
        ", Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
    public partial class tb_fornecedorTableAdapter : global::System.ComponentModel.Component {
        
        private global::System.Data.SqlClient.SqlDataAdapter _adapter;
        
        private global::System.Data.SqlClient.SqlConnection _connection;
        
        private global::System.Data.SqlClient.SqlTransaction _transaction;
        
        private global::System.Data.SqlClient.SqlCommand[] _commandCollection;
        
        private bool _clearBeforeFill;
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public tb_fornecedorTableAdapter() {
            this.ClearBeforeFill = true;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected internal global::System.Data.SqlClient.SqlDataAdapter Adapter {
            get {
                if ((this._adapter == null)) {
                    this.InitAdapter();
                }
                return this._adapter;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlConnection Connection {
            get {
                if ((this._connection == null)) {
                    this.InitConnection();
                }
                return this._connection;
            }
            set {
                this._connection = value;
                if ((this.Adapter.InsertCommand != null)) {
                    this.Adapter.InsertCommand.Connection = value;
                }
                if ((this.Adapter.DeleteCommand != null)) {
                    this.Adapter.DeleteCommand.Connection = value;
                }
                if ((this.Adapter.UpdateCommand != null)) {
                    this.Adapter.UpdateCommand.Connection = value;
                }
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    if ((this.CommandCollection[i] != null)) {
                        ((global::System.Data.SqlClient.SqlCommand)(this.CommandCollection[i])).Connection = value;
                    }
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlTransaction Transaction {
            get {
                return this._transaction;
            }
            set {
                this._transaction = value;
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    this.CommandCollection[i].Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.DeleteCommand != null))) {
                    this.Adapter.DeleteCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.InsertCommand != null))) {
                    this.Adapter.InsertCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.UpdateCommand != null))) {
                    this.Adapter.UpdateCommand.Transaction = this._transaction;
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected global::System.Data.SqlClient.SqlCommand[] CommandCollection {
            get {
                if ((this._commandCollection == null)) {
                    this.InitCommandCollection();
                }
                return this._commandCollection;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public bool ClearBeforeFill {
            get {
                return this._clearBeforeFill;
            }
            set {
                this._clearBeforeFill = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitAdapter() {
            this._adapter = new global::System.Data.SqlClient.SqlDataAdapter();
            global::System.Data.Common.DataTableMapping tableMapping = new global::System.Data.Common.DataTableMapping();
            tableMapping.SourceTable = "Table";
            tableMapping.DataSetTable = "tb_fornecedor";
            tableMapping.ColumnMappings.Add("cd_fornecedor", "cd_fornecedor");
            tableMapping.ColumnMappings.Add("nm_fornecedor", "nm_fornecedor");
            tableMapping.ColumnMappings.Add("ds_endereco", "ds_endereco");
            tableMapping.ColumnMappings.Add("nm_bairro", "nm_bairro");
            tableMapping.ColumnMappings.Add("nm_cidade", "nm_cidade");
            tableMapping.ColumnMappings.Add("sg_estado", "sg_estado");
            tableMapping.ColumnMappings.Add("cd_cep", "cd_cep");
            tableMapping.ColumnMappings.Add("cd_cnpj", "cd_cnpj");
            tableMapping.ColumnMappings.Add("cd_ie", "cd_ie");
            this._adapter.TableMappings.Add(tableMapping);
            this._adapter.DeleteCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.DeleteCommand.Connection = this.Connection;
            this._adapter.DeleteCommand.CommandText = @"DELETE FROM [tb_fornecedor] WHERE (([cd_fornecedor] = @Original_cd_fornecedor) AND ((@IsNull_nm_fornecedor = 1 AND [nm_fornecedor] IS NULL) OR ([nm_fornecedor] = @Original_nm_fornecedor)) AND ((@IsNull_ds_endereco = 1 AND [ds_endereco] IS NULL) OR ([ds_endereco] = @Original_ds_endereco)) AND ((@IsNull_nm_bairro = 1 AND [nm_bairro] IS NULL) OR ([nm_bairro] = @Original_nm_bairro)) AND ((@IsNull_nm_cidade = 1 AND [nm_cidade] IS NULL) OR ([nm_cidade] = @Original_nm_cidade)) AND ((@IsNull_sg_estado = 1 AND [sg_estado] IS NULL) OR ([sg_estado] = @Original_sg_estado)) AND ((@IsNull_cd_cep = 1 AND [cd_cep] IS NULL) OR ([cd_cep] = @Original_cd_cep)) AND ((@IsNull_cd_cnpj = 1 AND [cd_cnpj] IS NULL) OR ([cd_cnpj] = @Original_cd_cnpj)) AND ((@IsNull_cd_ie = 1 AND [cd_ie] IS NULL) OR ([cd_ie] = @Original_cd_ie)))";
            this._adapter.DeleteCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_fornecedor", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_fornecedor", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_fornecedor", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_fornecedor", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_fornecedor", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_fornecedor", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_ds_endereco", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_bairro", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_cidade", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_estado", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cep", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cnpj", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cnpj", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cnpj", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cnpj", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_ie", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_ie", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_ie", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_ie", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.InsertCommand.Connection = this.Connection;
            this._adapter.InsertCommand.CommandText = @"INSERT INTO [tb_fornecedor] ([nm_fornecedor], [ds_endereco], [nm_bairro], [nm_cidade], [sg_estado], [cd_cep], [cd_cnpj], [cd_ie]) VALUES (@nm_fornecedor, @ds_endereco, @nm_bairro, @nm_cidade, @sg_estado, @cd_cep, @cd_cnpj, @cd_ie);
SELECT cd_fornecedor, nm_fornecedor, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_cep, cd_cnpj, cd_ie FROM tb_fornecedor WHERE (cd_fornecedor = SCOPE_IDENTITY())";
            this._adapter.InsertCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_fornecedor", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_fornecedor", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cnpj", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cnpj", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_ie", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_ie", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.UpdateCommand.Connection = this.Connection;
            this._adapter.UpdateCommand.CommandText = @"UPDATE [tb_fornecedor] SET [nm_fornecedor] = @nm_fornecedor, [ds_endereco] = @ds_endereco, [nm_bairro] = @nm_bairro, [nm_cidade] = @nm_cidade, [sg_estado] = @sg_estado, [cd_cep] = @cd_cep, [cd_cnpj] = @cd_cnpj, [cd_ie] = @cd_ie WHERE (([cd_fornecedor] = @Original_cd_fornecedor) AND ((@IsNull_nm_fornecedor = 1 AND [nm_fornecedor] IS NULL) OR ([nm_fornecedor] = @Original_nm_fornecedor)) AND ((@IsNull_ds_endereco = 1 AND [ds_endereco] IS NULL) OR ([ds_endereco] = @Original_ds_endereco)) AND ((@IsNull_nm_bairro = 1 AND [nm_bairro] IS NULL) OR ([nm_bairro] = @Original_nm_bairro)) AND ((@IsNull_nm_cidade = 1 AND [nm_cidade] IS NULL) OR ([nm_cidade] = @Original_nm_cidade)) AND ((@IsNull_sg_estado = 1 AND [sg_estado] IS NULL) OR ([sg_estado] = @Original_sg_estado)) AND ((@IsNull_cd_cep = 1 AND [cd_cep] IS NULL) OR ([cd_cep] = @Original_cd_cep)) AND ((@IsNull_cd_cnpj = 1 AND [cd_cnpj] IS NULL) OR ([cd_cnpj] = @Original_cd_cnpj)) AND ((@IsNull_cd_ie = 1 AND [cd_ie] IS NULL) OR ([cd_ie] = @Original_cd_ie)));
SELECT cd_fornecedor, nm_fornecedor, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_cep, cd_cnpj, cd_ie FROM tb_fornecedor WHERE (cd_fornecedor = @cd_fornecedor)";
            this._adapter.UpdateCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_fornecedor", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_fornecedor", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_cnpj", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cnpj", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_ie", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_ie", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_fornecedor", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_fornecedor", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_fornecedor", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_fornecedor", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_fornecedor", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_fornecedor", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_ds_endereco", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_ds_endereco", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ds_endereco", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_bairro", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_bairro", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_bairro", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_cidade", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_cidade", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_cidade", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_estado", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_estado", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_estado", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cep", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cep", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cep", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_cnpj", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cnpj", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_cnpj", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_cnpj", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_ie", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_ie", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_ie", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_ie", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_fornecedor", global::System.Data.SqlDbType.Int, 4, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_fornecedor", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitConnection() {
            this._connection = new global::System.Data.SqlClient.SqlConnection();
            this._connection.ConnectionString = global::ProjetoEstoque.Properties.Settings.Default.bancoConnectionString;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitCommandCollection() {
            this._commandCollection = new global::System.Data.SqlClient.SqlCommand[1];
            this._commandCollection[0] = new global::System.Data.SqlClient.SqlCommand();
            this._commandCollection[0].Connection = this.Connection;
            this._commandCollection[0].CommandText = "SELECT cd_fornecedor, nm_fornecedor, ds_endereco, nm_bairro, nm_cidade, sg_estado" +
                ", cd_cep, cd_cnpj, cd_ie FROM tb_fornecedor";
            this._commandCollection[0].CommandType = global::System.Data.CommandType.Text;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Fill, true)]
        public virtual int Fill(bancoDataSet1.tb_fornecedorDataTable dataTable) {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            if ((this.ClearBeforeFill == true)) {
                dataTable.Clear();
            }
            int returnValue = this.Adapter.Fill(dataTable);
            return returnValue;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Select, true)]
        public virtual bancoDataSet1.tb_fornecedorDataTable GetData() {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            bancoDataSet1.tb_fornecedorDataTable dataTable = new bancoDataSet1.tb_fornecedorDataTable();
            this.Adapter.Fill(dataTable);
            return dataTable;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1.tb_fornecedorDataTable dataTable) {
            return this.Adapter.Update(dataTable);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1 dataSet) {
            return this.Adapter.Update(dataSet, "tb_fornecedor");
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow dataRow) {
            return this.Adapter.Update(new global::System.Data.DataRow[] {
                        dataRow});
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow[] dataRows) {
            return this.Adapter.Update(dataRows);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Delete, true)]
        public virtual int Delete(int Original_cd_fornecedor, string Original_nm_fornecedor, string Original_ds_endereco, string Original_nm_bairro, string Original_nm_cidade, string Original_sg_estado, string Original_cd_cep, string Original_cd_cnpj, string Original_cd_ie) {
            this.Adapter.DeleteCommand.Parameters[0].Value = ((int)(Original_cd_fornecedor));
            if ((Original_nm_fornecedor == null)) {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[2].Value = ((string)(Original_nm_fornecedor));
            }
            if ((Original_ds_endereco == null)) {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[4].Value = ((string)(Original_ds_endereco));
            }
            if ((Original_nm_bairro == null)) {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[6].Value = ((string)(Original_nm_bairro));
            }
            if ((Original_nm_cidade == null)) {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[8].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[8].Value = ((string)(Original_nm_cidade));
            }
            if ((Original_sg_estado == null)) {
                this.Adapter.DeleteCommand.Parameters[9].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[10].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[9].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[10].Value = ((string)(Original_sg_estado));
            }
            if ((Original_cd_cep == null)) {
                this.Adapter.DeleteCommand.Parameters[11].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[12].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[11].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[12].Value = ((string)(Original_cd_cep));
            }
            if ((Original_cd_cnpj == null)) {
                this.Adapter.DeleteCommand.Parameters[13].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[14].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[13].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[14].Value = ((string)(Original_cd_cnpj));
            }
            if ((Original_cd_ie == null)) {
                this.Adapter.DeleteCommand.Parameters[15].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[16].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[15].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[16].Value = ((string)(Original_cd_ie));
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.DeleteCommand.Connection.State;
            if (((this.Adapter.DeleteCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.DeleteCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.DeleteCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.DeleteCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Insert, true)]
        public virtual int Insert(string nm_fornecedor, string ds_endereco, string nm_bairro, string nm_cidade, string sg_estado, string cd_cep, string cd_cnpj, string cd_ie) {
            if ((nm_fornecedor == null)) {
                this.Adapter.InsertCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[0].Value = ((string)(nm_fornecedor));
            }
            if ((ds_endereco == null)) {
                this.Adapter.InsertCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[1].Value = ((string)(ds_endereco));
            }
            if ((nm_bairro == null)) {
                this.Adapter.InsertCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[2].Value = ((string)(nm_bairro));
            }
            if ((nm_cidade == null)) {
                this.Adapter.InsertCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[3].Value = ((string)(nm_cidade));
            }
            if ((sg_estado == null)) {
                this.Adapter.InsertCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[4].Value = ((string)(sg_estado));
            }
            if ((cd_cep == null)) {
                this.Adapter.InsertCommand.Parameters[5].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[5].Value = ((string)(cd_cep));
            }
            if ((cd_cnpj == null)) {
                this.Adapter.InsertCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[6].Value = ((string)(cd_cnpj));
            }
            if ((cd_ie == null)) {
                this.Adapter.InsertCommand.Parameters[7].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[7].Value = ((string)(cd_ie));
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.InsertCommand.Connection.State;
            if (((this.Adapter.InsertCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.InsertCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.InsertCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.InsertCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(
                    string nm_fornecedor, 
                    string ds_endereco, 
                    string nm_bairro, 
                    string nm_cidade, 
                    string sg_estado, 
                    string cd_cep, 
                    string cd_cnpj, 
                    string cd_ie, 
                    int Original_cd_fornecedor, 
                    string Original_nm_fornecedor, 
                    string Original_ds_endereco, 
                    string Original_nm_bairro, 
                    string Original_nm_cidade, 
                    string Original_sg_estado, 
                    string Original_cd_cep, 
                    string Original_cd_cnpj, 
                    string Original_cd_ie, 
                    int cd_fornecedor) {
            if ((nm_fornecedor == null)) {
                this.Adapter.UpdateCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[0].Value = ((string)(nm_fornecedor));
            }
            if ((ds_endereco == null)) {
                this.Adapter.UpdateCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[1].Value = ((string)(ds_endereco));
            }
            if ((nm_bairro == null)) {
                this.Adapter.UpdateCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[2].Value = ((string)(nm_bairro));
            }
            if ((nm_cidade == null)) {
                this.Adapter.UpdateCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[3].Value = ((string)(nm_cidade));
            }
            if ((sg_estado == null)) {
                this.Adapter.UpdateCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[4].Value = ((string)(sg_estado));
            }
            if ((cd_cep == null)) {
                this.Adapter.UpdateCommand.Parameters[5].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[5].Value = ((string)(cd_cep));
            }
            if ((cd_cnpj == null)) {
                this.Adapter.UpdateCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[6].Value = ((string)(cd_cnpj));
            }
            if ((cd_ie == null)) {
                this.Adapter.UpdateCommand.Parameters[7].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[7].Value = ((string)(cd_ie));
            }
            this.Adapter.UpdateCommand.Parameters[8].Value = ((int)(Original_cd_fornecedor));
            if ((Original_nm_fornecedor == null)) {
                this.Adapter.UpdateCommand.Parameters[9].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[10].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[9].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[10].Value = ((string)(Original_nm_fornecedor));
            }
            if ((Original_ds_endereco == null)) {
                this.Adapter.UpdateCommand.Parameters[11].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[12].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[11].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[12].Value = ((string)(Original_ds_endereco));
            }
            if ((Original_nm_bairro == null)) {
                this.Adapter.UpdateCommand.Parameters[13].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[14].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[13].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[14].Value = ((string)(Original_nm_bairro));
            }
            if ((Original_nm_cidade == null)) {
                this.Adapter.UpdateCommand.Parameters[15].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[16].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[15].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[16].Value = ((string)(Original_nm_cidade));
            }
            if ((Original_sg_estado == null)) {
                this.Adapter.UpdateCommand.Parameters[17].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[18].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[17].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[18].Value = ((string)(Original_sg_estado));
            }
            if ((Original_cd_cep == null)) {
                this.Adapter.UpdateCommand.Parameters[19].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[20].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[19].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[20].Value = ((string)(Original_cd_cep));
            }
            if ((Original_cd_cnpj == null)) {
                this.Adapter.UpdateCommand.Parameters[21].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[22].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[21].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[22].Value = ((string)(Original_cd_cnpj));
            }
            if ((Original_cd_ie == null)) {
                this.Adapter.UpdateCommand.Parameters[23].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[24].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[23].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[24].Value = ((string)(Original_cd_ie));
            }
            this.Adapter.UpdateCommand.Parameters[25].Value = ((int)(cd_fornecedor));
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.UpdateCommand.Connection.State;
            if (((this.Adapter.UpdateCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.UpdateCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.UpdateCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.UpdateCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(
                    string nm_fornecedor, 
                    string ds_endereco, 
                    string nm_bairro, 
                    string nm_cidade, 
                    string sg_estado, 
                    string cd_cep, 
                    string cd_cnpj, 
                    string cd_ie, 
                    int Original_cd_fornecedor, 
                    string Original_nm_fornecedor, 
                    string Original_ds_endereco, 
                    string Original_nm_bairro, 
                    string Original_nm_cidade, 
                    string Original_sg_estado, 
                    string Original_cd_cep, 
                    string Original_cd_cnpj, 
                    string Original_cd_ie) {
            return this.Update(nm_fornecedor, ds_endereco, nm_bairro, nm_cidade, sg_estado, cd_cep, cd_cnpj, cd_ie, Original_cd_fornecedor, Original_nm_fornecedor, Original_ds_endereco, Original_nm_bairro, Original_nm_cidade, Original_sg_estado, Original_cd_cep, Original_cd_cnpj, Original_cd_ie, Original_cd_fornecedor);
        }
    }
    
    [global::System.ComponentModel.DesignerCategoryAttribute("code")]
    [global::System.ComponentModel.ToolboxItem(true)]
    [global::System.ComponentModel.DataObjectAttribute(true)]
    [global::System.ComponentModel.DesignerAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner" +
        ", Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
    public partial class tb_usuarioTableAdapter : global::System.ComponentModel.Component {
        
        private global::System.Data.SqlClient.SqlDataAdapter _adapter;
        
        private global::System.Data.SqlClient.SqlConnection _connection;
        
        private global::System.Data.SqlClient.SqlTransaction _transaction;
        
        private global::System.Data.SqlClient.SqlCommand[] _commandCollection;
        
        private bool _clearBeforeFill;
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public tb_usuarioTableAdapter() {
            this.ClearBeforeFill = true;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected internal global::System.Data.SqlClient.SqlDataAdapter Adapter {
            get {
                if ((this._adapter == null)) {
                    this.InitAdapter();
                }
                return this._adapter;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlConnection Connection {
            get {
                if ((this._connection == null)) {
                    this.InitConnection();
                }
                return this._connection;
            }
            set {
                this._connection = value;
                if ((this.Adapter.InsertCommand != null)) {
                    this.Adapter.InsertCommand.Connection = value;
                }
                if ((this.Adapter.DeleteCommand != null)) {
                    this.Adapter.DeleteCommand.Connection = value;
                }
                if ((this.Adapter.UpdateCommand != null)) {
                    this.Adapter.UpdateCommand.Connection = value;
                }
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    if ((this.CommandCollection[i] != null)) {
                        ((global::System.Data.SqlClient.SqlCommand)(this.CommandCollection[i])).Connection = value;
                    }
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlTransaction Transaction {
            get {
                return this._transaction;
            }
            set {
                this._transaction = value;
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    this.CommandCollection[i].Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.DeleteCommand != null))) {
                    this.Adapter.DeleteCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.InsertCommand != null))) {
                    this.Adapter.InsertCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.UpdateCommand != null))) {
                    this.Adapter.UpdateCommand.Transaction = this._transaction;
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected global::System.Data.SqlClient.SqlCommand[] CommandCollection {
            get {
                if ((this._commandCollection == null)) {
                    this.InitCommandCollection();
                }
                return this._commandCollection;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public bool ClearBeforeFill {
            get {
                return this._clearBeforeFill;
            }
            set {
                this._clearBeforeFill = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitAdapter() {
            this._adapter = new global::System.Data.SqlClient.SqlDataAdapter();
            global::System.Data.Common.DataTableMapping tableMapping = new global::System.Data.Common.DataTableMapping();
            tableMapping.SourceTable = "Table";
            tableMapping.DataSetTable = "tb_usuario";
            tableMapping.ColumnMappings.Add("cd_usuario", "cd_usuario");
            tableMapping.ColumnMappings.Add("nm_usuario", "nm_usuario");
            tableMapping.ColumnMappings.Add("sg_nivel", "sg_nivel");
            tableMapping.ColumnMappings.Add("nm_login", "nm_login");
            tableMapping.ColumnMappings.Add("cd_senha", "cd_senha");
            this._adapter.TableMappings.Add(tableMapping);
            this._adapter.DeleteCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.DeleteCommand.Connection = this.Connection;
            this._adapter.DeleteCommand.CommandText = @"DELETE FROM [tb_usuario] WHERE (([cd_usuario] = @Original_cd_usuario) AND ((@IsNull_nm_usuario = 1 AND [nm_usuario] IS NULL) OR ([nm_usuario] = @Original_nm_usuario)) AND ((@IsNull_sg_nivel = 1 AND [sg_nivel] IS NULL) OR ([sg_nivel] = @Original_sg_nivel)) AND ((@IsNull_nm_login = 1 AND [nm_login] IS NULL) OR ([nm_login] = @Original_nm_login)) AND ((@IsNull_cd_senha = 1 AND [cd_senha] IS NULL) OR ([cd_senha] = @Original_cd_senha)))";
            this._adapter.DeleteCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_usuario", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_usuario", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_usuario", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_usuario", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_usuario", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_usuario", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_nivel", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_nivel", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_nivel", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_nivel", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_login", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_login", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_login", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_login", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_senha", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_senha", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_senha", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_senha", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.InsertCommand.Connection = this.Connection;
            this._adapter.InsertCommand.CommandText = "INSERT INTO [tb_usuario] ([nm_usuario], [sg_nivel], [nm_login], [cd_senha])" +
                " VALUES (@nm_usuario, @sg_nivel, @nm_login, @cd_senha);\r\nSELECT cd_usuario, nm_u" +
                "suario, sg_nivel, nm_login, cd_senha FROM tb_usuario WHERE (cd_usuario = SCOPE_I" +
                "DENTITY())";
            this._adapter.InsertCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_usuario", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_usuario", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_nivel", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_nivel", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_login", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_login", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_senha", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_senha", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.UpdateCommand.Connection = this.Connection;
            this._adapter.UpdateCommand.CommandText = @"UPDATE [tb_usuario] SET [nm_usuario] = @nm_usuario, [sg_nivel] = @sg_nivel, [nm_login] = @nm_login, [cd_senha] = @cd_senha WHERE (([cd_usuario] = @Original_cd_usuario) AND ((@IsNull_nm_usuario = 1 AND [nm_usuario] IS NULL) OR ([nm_usuario] = @Original_nm_usuario)) AND ((@IsNull_sg_nivel = 1 AND [sg_nivel] IS NULL) OR ([sg_nivel] = @Original_sg_nivel)) AND ((@IsNull_nm_login = 1 AND [nm_login] IS NULL) OR ([nm_login] = @Original_nm_login)) AND ((@IsNull_cd_senha = 1 AND [cd_senha] IS NULL) OR ([cd_senha] = @Original_cd_senha)));
SELECT cd_usuario, nm_usuario, sg_nivel, nm_login, cd_senha FROM tb_usuario WHERE (cd_usuario = @cd_usuario)";
            this._adapter.UpdateCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_usuario", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_usuario", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_nivel", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_nivel", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_login", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_login", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_senha", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_senha", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_usuario", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_usuario", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_usuario", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_usuario", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_usuario", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_usuario", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_nivel", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_nivel", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_nivel", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_nivel", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_login", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_login", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_login", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_login", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_cd_senha", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_senha", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_senha", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_senha", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_usuario", global::System.Data.SqlDbType.Int, 4, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_usuario", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitConnection() {
            this._connection = new global::System.Data.SqlClient.SqlConnection();
            this._connection.ConnectionString = global::ProjetoEstoque.Properties.Settings.Default.bancoConnectionString;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitCommandCollection() {
            this._commandCollection = new global::System.Data.SqlClient.SqlCommand[1];
            this._commandCollection[0] = new global::System.Data.SqlClient.SqlCommand();
            this._commandCollection[0].Connection = this.Connection;
            this._commandCollection[0].CommandText = "SELECT cd_usuario, nm_usuario, sg_nivel, nm_login, cd_senha FROM tb_usuario";
            this._commandCollection[0].CommandType = global::System.Data.CommandType.Text;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Fill, true)]
        public virtual int Fill(bancoDataSet1.tb_usuarioDataTable dataTable) {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            if ((this.ClearBeforeFill == true)) {
                dataTable.Clear();
            }
            int returnValue = this.Adapter.Fill(dataTable);
            return returnValue;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Select, true)]
        public virtual bancoDataSet1.tb_usuarioDataTable GetData() {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            bancoDataSet1.tb_usuarioDataTable dataTable = new bancoDataSet1.tb_usuarioDataTable();
            this.Adapter.Fill(dataTable);
            return dataTable;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1.tb_usuarioDataTable dataTable) {
            return this.Adapter.Update(dataTable);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1 dataSet) {
            return this.Adapter.Update(dataSet, "tb_usuario");
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow dataRow) {
            return this.Adapter.Update(new global::System.Data.DataRow[] {
                        dataRow});
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow[] dataRows) {
            return this.Adapter.Update(dataRows);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Delete, true)]
        public virtual int Delete(int Original_cd_usuario, string Original_nm_usuario, string Original_sg_nivel, string Original_nm_login, string Original_cd_senha) {
            this.Adapter.DeleteCommand.Parameters[0].Value = ((int)(Original_cd_usuario));
            if ((Original_nm_usuario == null)) {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[2].Value = ((string)(Original_nm_usuario));
            }
            if ((Original_sg_nivel == null)) {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[4].Value = ((string)(Original_sg_nivel));
            }
            if ((Original_nm_login == null)) {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[6].Value = ((string)(Original_nm_login));
            }
            if ((Original_cd_senha == null)) {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[8].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[8].Value = ((string)(Original_cd_senha));
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.DeleteCommand.Connection.State;
            if (((this.Adapter.DeleteCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.DeleteCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.DeleteCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.DeleteCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Insert, true)]
        public virtual int Insert(string nm_usuario, string sg_nivel, string nm_login, string cd_senha) {
            if ((nm_usuario == null)) {
                this.Adapter.InsertCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[0].Value = ((string)(nm_usuario));
            }
            if ((sg_nivel == null)) {
                this.Adapter.InsertCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[1].Value = ((string)(sg_nivel));
            }
            if ((nm_login == null)) {
                this.Adapter.InsertCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[2].Value = ((string)(nm_login));
            }
            if ((cd_senha == null)) {
                this.Adapter.InsertCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[3].Value = ((string)(cd_senha));
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.InsertCommand.Connection.State;
            if (((this.Adapter.InsertCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.InsertCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.InsertCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.InsertCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(string nm_usuario, string sg_nivel, string nm_login, string cd_senha, int Original_cd_usuario, string Original_nm_usuario, string Original_sg_nivel, string Original_nm_login, string Original_cd_senha, int cd_usuario) {
            if ((nm_usuario == null)) {
                this.Adapter.UpdateCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[0].Value = ((string)(nm_usuario));
            }
            if ((sg_nivel == null)) {
                this.Adapter.UpdateCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[1].Value = ((string)(sg_nivel));
            }
            if ((nm_login == null)) {
                this.Adapter.UpdateCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[2].Value = ((string)(nm_login));
            }
            if ((cd_senha == null)) {
                this.Adapter.UpdateCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[3].Value = ((string)(cd_senha));
            }
            this.Adapter.UpdateCommand.Parameters[4].Value = ((int)(Original_cd_usuario));
            if ((Original_nm_usuario == null)) {
                this.Adapter.UpdateCommand.Parameters[5].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[5].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[6].Value = ((string)(Original_nm_usuario));
            }
            if ((Original_sg_nivel == null)) {
                this.Adapter.UpdateCommand.Parameters[7].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[8].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[7].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[8].Value = ((string)(Original_sg_nivel));
            }
            if ((Original_nm_login == null)) {
                this.Adapter.UpdateCommand.Parameters[9].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[10].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[9].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[10].Value = ((string)(Original_nm_login));
            }
            if ((Original_cd_senha == null)) {
                this.Adapter.UpdateCommand.Parameters[11].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[12].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[11].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[12].Value = ((string)(Original_cd_senha));
            }
            this.Adapter.UpdateCommand.Parameters[13].Value = ((int)(cd_usuario));
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.UpdateCommand.Connection.State;
            if (((this.Adapter.UpdateCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.UpdateCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.UpdateCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.UpdateCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(string nm_usuario, string sg_nivel, string nm_login, string cd_senha, int Original_cd_usuario, string Original_nm_usuario, string Original_sg_nivel, string Original_nm_login, string Original_cd_senha) {
            return this.Update(nm_usuario, sg_nivel, nm_login, cd_senha, Original_cd_usuario, Original_nm_usuario, Original_sg_nivel, Original_nm_login, Original_cd_senha, Original_cd_usuario);
        }
    }
    
    [global::System.ComponentModel.DesignerCategoryAttribute("code")]
    [global::System.ComponentModel.ToolboxItem(true)]
    [global::System.ComponentModel.DataObjectAttribute(true)]
    [global::System.ComponentModel.DesignerAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterDesigner, Microsoft.VSDesigner" +
        ", Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
    public partial class tb_produtosTableAdapter : global::System.ComponentModel.Component {
        
        private global::System.Data.SqlClient.SqlDataAdapter _adapter;
        
        private global::System.Data.SqlClient.SqlConnection _connection;
        
        private global::System.Data.SqlClient.SqlTransaction _transaction;
        
        private global::System.Data.SqlClient.SqlCommand[] _commandCollection;
        
        private bool _clearBeforeFill;
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public tb_produtosTableAdapter() {
            this.ClearBeforeFill = true;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected internal global::System.Data.SqlClient.SqlDataAdapter Adapter {
            get {
                if ((this._adapter == null)) {
                    this.InitAdapter();
                }
                return this._adapter;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlConnection Connection {
            get {
                if ((this._connection == null)) {
                    this.InitConnection();
                }
                return this._connection;
            }
            set {
                this._connection = value;
                if ((this.Adapter.InsertCommand != null)) {
                    this.Adapter.InsertCommand.Connection = value;
                }
                if ((this.Adapter.DeleteCommand != null)) {
                    this.Adapter.DeleteCommand.Connection = value;
                }
                if ((this.Adapter.UpdateCommand != null)) {
                    this.Adapter.UpdateCommand.Connection = value;
                }
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    if ((this.CommandCollection[i] != null)) {
                        ((global::System.Data.SqlClient.SqlCommand)(this.CommandCollection[i])).Connection = value;
                    }
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        internal global::System.Data.SqlClient.SqlTransaction Transaction {
            get {
                return this._transaction;
            }
            set {
                this._transaction = value;
                for (int i = 0; (i < this.CommandCollection.Length); i = (i + 1)) {
                    this.CommandCollection[i].Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.DeleteCommand != null))) {
                    this.Adapter.DeleteCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.InsertCommand != null))) {
                    this.Adapter.InsertCommand.Transaction = this._transaction;
                }
                if (((this.Adapter != null) 
                            && (this.Adapter.UpdateCommand != null))) {
                    this.Adapter.UpdateCommand.Transaction = this._transaction;
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected global::System.Data.SqlClient.SqlCommand[] CommandCollection {
            get {
                if ((this._commandCollection == null)) {
                    this.InitCommandCollection();
                }
                return this._commandCollection;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public bool ClearBeforeFill {
            get {
                return this._clearBeforeFill;
            }
            set {
                this._clearBeforeFill = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitAdapter() {
            this._adapter = new global::System.Data.SqlClient.SqlDataAdapter();
            global::System.Data.Common.DataTableMapping tableMapping = new global::System.Data.Common.DataTableMapping();
            tableMapping.SourceTable = "Table";
            tableMapping.DataSetTable = "tb_produtos";
            tableMapping.ColumnMappings.Add("cd_produto", "cd_produto");
            tableMapping.ColumnMappings.Add("nm_produto", "nm_produto");
            tableMapping.ColumnMappings.Add("sg_unidade_venda_produto", "sg_unidade_venda_produto");
            tableMapping.ColumnMappings.Add("vl_custo", "vl_custo");
            tableMapping.ColumnMappings.Add("vl_venda", "vl_venda");
            tableMapping.ColumnMappings.Add("qt_estoque", "qt_estoque");
            this._adapter.TableMappings.Add(tableMapping);
            this._adapter.DeleteCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.DeleteCommand.Connection = this.Connection;
            this._adapter.DeleteCommand.CommandText = @"DELETE FROM [tb_produtos] WHERE (([cd_produto] = @Original_cd_produto) AND ((@IsNull_nm_produto = 1 AND [nm_produto] IS NULL) OR ([nm_produto] = @Original_nm_produto)) AND ((@IsNull_sg_unidade_venda_produto = 1 AND [sg_unidade_venda_produto] IS NULL) OR ([sg_unidade_venda_produto] = @Original_sg_unidade_venda_produto)) AND ((@IsNull_vl_custo = 1 AND [vl_custo] IS NULL) OR ([vl_custo] = @Original_vl_custo)) AND ((@IsNull_vl_venda = 1 AND [vl_venda] IS NULL) OR ([vl_venda] = @Original_vl_venda)) AND ((@IsNull_qt_estoque = 1 AND [qt_estoque] IS NULL) OR ([qt_estoque] = @Original_qt_estoque)))";
            this._adapter.DeleteCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_produto", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_produto", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_unidade_venda_produto", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_unidade_venda_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_unidade_venda_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_unidade_venda_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_vl_custo", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "vl_custo", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_vl_custo", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_custo", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_vl_venda", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "vl_venda", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_vl_venda", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_venda", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_qt_estoque", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "qt_estoque", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.DeleteCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_qt_estoque", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "qt_estoque", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.InsertCommand.Connection = this.Connection;
            this._adapter.InsertCommand.CommandText = @"INSERT INTO [tb_produtos] ([nm_produto], [sg_unidade_venda_produto], [vl_custo], [vl_venda], [qt_estoque]) VALUES (@nm_produto, @sg_unidade_venda_produto, @vl_custo, @vl_venda, @qt_estoque);
SELECT cd_produto, nm_produto, sg_unidade_venda_produto, vl_custo, vl_venda, qt_estoque FROM tb_produtos WHERE (cd_produto = SCOPE_IDENTITY())";
            this._adapter.InsertCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_produto", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_unidade_venda_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_unidade_venda_produto", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@vl_custo", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_custo", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@vl_venda", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_venda", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.InsertCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@qt_estoque", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "qt_estoque", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand = new global::System.Data.SqlClient.SqlCommand();
            this._adapter.UpdateCommand.Connection = this.Connection;
            this._adapter.UpdateCommand.CommandText = @"UPDATE [tb_produtos] SET [nm_produto] = @nm_produto, [sg_unidade_venda_produto] = @sg_unidade_venda_produto, [vl_custo] = @vl_custo, [vl_venda] = @vl_venda, [qt_estoque] = @qt_estoque WHERE (([cd_produto] = @Original_cd_produto) AND ((@IsNull_nm_produto = 1 AND [nm_produto] IS NULL) OR ([nm_produto] = @Original_nm_produto)) AND ((@IsNull_sg_unidade_venda_produto = 1 AND [sg_unidade_venda_produto] IS NULL) OR ([sg_unidade_venda_produto] = @Original_sg_unidade_venda_produto)) AND ((@IsNull_vl_custo = 1 AND [vl_custo] IS NULL) OR ([vl_custo] = @Original_vl_custo)) AND ((@IsNull_vl_venda = 1 AND [vl_venda] IS NULL) OR ([vl_venda] = @Original_vl_venda)) AND ((@IsNull_qt_estoque = 1 AND [qt_estoque] IS NULL) OR ([qt_estoque] = @Original_qt_estoque)));
SELECT cd_produto, nm_produto, sg_unidade_venda_produto, vl_custo, vl_venda, qt_estoque FROM tb_produtos WHERE (cd_produto = @cd_produto)";
            this._adapter.UpdateCommand.CommandType = global::System.Data.CommandType.Text;
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@nm_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_produto", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@sg_unidade_venda_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_unidade_venda_produto", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@vl_custo", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_custo", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@vl_venda", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_venda", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@qt_estoque", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "qt_estoque", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_cd_produto", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_nm_produto", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_nm_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "nm_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_sg_unidade_venda_produto", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_unidade_venda_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_sg_unidade_venda_produto", global::System.Data.SqlDbType.VarChar, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "sg_unidade_venda_produto", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_vl_custo", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "vl_custo", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_vl_custo", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_custo", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_vl_venda", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "vl_venda", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_vl_venda", global::System.Data.SqlDbType.Decimal, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(14)), ((byte)(2)), "vl_venda", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@IsNull_qt_estoque", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "qt_estoque", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = true });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@Original_qt_estoque", global::System.Data.SqlDbType.Int, 0, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "qt_estoque", global::System.Data.DataRowVersion.Original, null) { SourceColumnNullMapping = false });
            this._adapter.UpdateCommand.Parameters.Add(new global::System.Data.SqlClient.SqlParameter("@cd_produto", global::System.Data.SqlDbType.Int, 4, global::System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "cd_produto", global::System.Data.DataRowVersion.Current, null) { SourceColumnNullMapping = false });
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitConnection() {
            this._connection = new global::System.Data.SqlClient.SqlConnection();
            this._connection.ConnectionString = global::ProjetoEstoque.Properties.Settings.Default.bancoConnectionString;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private void InitCommandCollection() {
            this._commandCollection = new global::System.Data.SqlClient.SqlCommand[1];
            this._commandCollection[0] = new global::System.Data.SqlClient.SqlCommand();
            this._commandCollection[0].Connection = this.Connection;
            this._commandCollection[0].CommandText = "SELECT cd_produto, nm_produto, sg_unidade_venda_produto, vl_custo, vl_venda, qt_e" +
                "stoque FROM tb_produtos";
            this._commandCollection[0].CommandType = global::System.Data.CommandType.Text;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Fill, true)]
        public virtual int Fill(bancoDataSet1.tb_produtosDataTable dataTable) {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            if ((this.ClearBeforeFill == true)) {
                dataTable.Clear();
            }
            int returnValue = this.Adapter.Fill(dataTable);
            return returnValue;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Select, true)]
        public virtual bancoDataSet1.tb_produtosDataTable GetData() {
            this.Adapter.SelectCommand = this.CommandCollection[0];
            bancoDataSet1.tb_produtosDataTable dataTable = new bancoDataSet1.tb_produtosDataTable();
            this.Adapter.Fill(dataTable);
            return dataTable;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1.tb_produtosDataTable dataTable) {
            return this.Adapter.Update(dataTable);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(bancoDataSet1 dataSet) {
            return this.Adapter.Update(dataSet, "tb_produtos");
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow dataRow) {
            return this.Adapter.Update(new global::System.Data.DataRow[] {
                        dataRow});
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        public virtual int Update(global::System.Data.DataRow[] dataRows) {
            return this.Adapter.Update(dataRows);
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Delete, true)]
        public virtual int Delete(int Original_cd_produto, string Original_nm_produto, string Original_sg_unidade_venda_produto, global::System.Nullable<decimal> Original_vl_custo, global::System.Nullable<decimal> Original_vl_venda, global::System.Nullable<int> Original_qt_estoque) {
            this.Adapter.DeleteCommand.Parameters[0].Value = ((int)(Original_cd_produto));
            if ((Original_nm_produto == null)) {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[1].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[2].Value = ((string)(Original_nm_produto));
            }
            if ((Original_sg_unidade_venda_produto == null)) {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.DeleteCommand.Parameters[3].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[4].Value = ((string)(Original_sg_unidade_venda_produto));
            }
            if ((Original_vl_custo.HasValue == true)) {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[6].Value = ((decimal)(Original_vl_custo.Value));
            }
            else {
                this.Adapter.DeleteCommand.Parameters[5].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[6].Value = global::System.DBNull.Value;
            }
            if ((Original_vl_venda.HasValue == true)) {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[8].Value = ((decimal)(Original_vl_venda.Value));
            }
            else {
                this.Adapter.DeleteCommand.Parameters[7].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[8].Value = global::System.DBNull.Value;
            }
            if ((Original_qt_estoque.HasValue == true)) {
                this.Adapter.DeleteCommand.Parameters[9].Value = ((object)(0));
                this.Adapter.DeleteCommand.Parameters[10].Value = ((int)(Original_qt_estoque.Value));
            }
            else {
                this.Adapter.DeleteCommand.Parameters[9].Value = ((object)(1));
                this.Adapter.DeleteCommand.Parameters[10].Value = global::System.DBNull.Value;
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.DeleteCommand.Connection.State;
            if (((this.Adapter.DeleteCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.DeleteCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.DeleteCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.DeleteCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Insert, true)]
        public virtual int Insert(string nm_produto, string sg_unidade_venda_produto, global::System.Nullable<decimal> vl_custo, global::System.Nullable<decimal> vl_venda, global::System.Nullable<int> qt_estoque) {
            if ((nm_produto == null)) {
                this.Adapter.InsertCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[0].Value = ((string)(nm_produto));
            }
            if ((sg_unidade_venda_produto == null)) {
                this.Adapter.InsertCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.InsertCommand.Parameters[1].Value = ((string)(sg_unidade_venda_produto));
            }
            if ((vl_custo.HasValue == true)) {
                this.Adapter.InsertCommand.Parameters[2].Value = ((decimal)(vl_custo.Value));
            }
            else {
                this.Adapter.InsertCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            if ((vl_venda.HasValue == true)) {
                this.Adapter.InsertCommand.Parameters[3].Value = ((decimal)(vl_venda.Value));
            }
            else {
                this.Adapter.InsertCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            if ((qt_estoque.HasValue == true)) {
                this.Adapter.InsertCommand.Parameters[4].Value = ((int)(qt_estoque.Value));
            }
            else {
                this.Adapter.InsertCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.InsertCommand.Connection.State;
            if (((this.Adapter.InsertCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.InsertCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.InsertCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.InsertCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(string nm_produto, string sg_unidade_venda_produto, global::System.Nullable<decimal> vl_custo, global::System.Nullable<decimal> vl_venda, global::System.Nullable<int> qt_estoque, int Original_cd_produto, string Original_nm_produto, string Original_sg_unidade_venda_produto, global::System.Nullable<decimal> Original_vl_custo, global::System.Nullable<decimal> Original_vl_venda, global::System.Nullable<int> Original_qt_estoque, int cd_produto) {
            if ((nm_produto == null)) {
                this.Adapter.UpdateCommand.Parameters[0].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[0].Value = ((string)(nm_produto));
            }
            if ((sg_unidade_venda_produto == null)) {
                this.Adapter.UpdateCommand.Parameters[1].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[1].Value = ((string)(sg_unidade_venda_produto));
            }
            if ((vl_custo.HasValue == true)) {
                this.Adapter.UpdateCommand.Parameters[2].Value = ((decimal)(vl_custo.Value));
            }
            else {
                this.Adapter.UpdateCommand.Parameters[2].Value = global::System.DBNull.Value;
            }
            if ((vl_venda.HasValue == true)) {
                this.Adapter.UpdateCommand.Parameters[3].Value = ((decimal)(vl_venda.Value));
            }
            else {
                this.Adapter.UpdateCommand.Parameters[3].Value = global::System.DBNull.Value;
            }
            if ((qt_estoque.HasValue == true)) {
                this.Adapter.UpdateCommand.Parameters[4].Value = ((int)(qt_estoque.Value));
            }
            else {
                this.Adapter.UpdateCommand.Parameters[4].Value = global::System.DBNull.Value;
            }
            this.Adapter.UpdateCommand.Parameters[5].Value = ((int)(Original_cd_produto));
            if ((Original_nm_produto == null)) {
                this.Adapter.UpdateCommand.Parameters[6].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[7].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[6].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[7].Value = ((string)(Original_nm_produto));
            }
            if ((Original_sg_unidade_venda_produto == null)) {
                this.Adapter.UpdateCommand.Parameters[8].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[9].Value = global::System.DBNull.Value;
            }
            else {
                this.Adapter.UpdateCommand.Parameters[8].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[9].Value = ((string)(Original_sg_unidade_venda_produto));
            }
            if ((Original_vl_custo.HasValue == true)) {
                this.Adapter.UpdateCommand.Parameters[10].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[11].Value = ((decimal)(Original_vl_custo.Value));
            }
            else {
                this.Adapter.UpdateCommand.Parameters[10].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[11].Value = global::System.DBNull.Value;
            }
            if ((Original_vl_venda.HasValue == true)) {
                this.Adapter.UpdateCommand.Parameters[12].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[13].Value = ((decimal)(Original_vl_venda.Value));
            }
            else {
                this.Adapter.UpdateCommand.Parameters[12].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[13].Value = global::System.DBNull.Value;
            }
            if ((Original_qt_estoque.HasValue == true)) {
                this.Adapter.UpdateCommand.Parameters[14].Value = ((object)(0));
                this.Adapter.UpdateCommand.Parameters[15].Value = ((int)(Original_qt_estoque.Value));
            }
            else {
                this.Adapter.UpdateCommand.Parameters[14].Value = ((object)(1));
                this.Adapter.UpdateCommand.Parameters[15].Value = global::System.DBNull.Value;
            }
            this.Adapter.UpdateCommand.Parameters[16].Value = ((int)(cd_produto));
            global::System.Data.ConnectionState previousConnectionState = this.Adapter.UpdateCommand.Connection.State;
            if (((this.Adapter.UpdateCommand.Connection.State & global::System.Data.ConnectionState.Open) 
                        != global::System.Data.ConnectionState.Open)) {
                this.Adapter.UpdateCommand.Connection.Open();
            }
            try {
                int returnValue = this.Adapter.UpdateCommand.ExecuteNonQuery();
                return returnValue;
            }
            finally {
                if ((previousConnectionState == global::System.Data.ConnectionState.Closed)) {
                    this.Adapter.UpdateCommand.Connection.Close();
                }
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapter")]
        [global::System.ComponentModel.DataObjectMethodAttribute(global::System.ComponentModel.DataObjectMethodType.Update, true)]
        public virtual int Update(string nm_produto, string sg_unidade_venda_produto, global::System.Nullable<decimal> vl_custo, global::System.Nullable<decimal> vl_venda, global::System.Nullable<int> qt_estoque, int Original_cd_produto, string Original_nm_produto, string Original_sg_unidade_venda_produto, global::System.Nullable<decimal> Original_vl_custo, global::System.Nullable<decimal> Original_vl_venda, global::System.Nullable<int> Original_qt_estoque) {
            return this.Update(nm_produto, sg_unidade_venda_produto, vl_custo, vl_venda, qt_estoque, Original_cd_produto, Original_nm_produto, Original_sg_unidade_venda_produto, Original_vl_custo, Original_vl_venda, Original_qt_estoque, Original_cd_produto);
        }
    }
    
    [global::System.ComponentModel.DesignerCategoryAttribute("code")]
    [global::System.ComponentModel.ToolboxItem(true)]
    [global::System.ComponentModel.DesignerAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterManagerDesigner, Microsoft.VSD" +
        "esigner, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [global::System.ComponentModel.Design.HelpKeywordAttribute("vs.data.TableAdapterManager")]
    public partial class TableAdapterManager : global::System.ComponentModel.Component {
        
        private UpdateOrderOption _updateOrder;
        
        private tb_clienteTableAdapter _tb_clienteTableAdapter;
        
        private tb_fornecedorTableAdapter _tb_fornecedorTableAdapter;
        
        private tb_usuarioTableAdapter _tb_usuarioTableAdapter;
        
        private tb_produtosTableAdapter _tb_produtosTableAdapter;
        
        private bool _backupDataSetBeforeUpdate;
        
        private global::System.Data.IDbConnection _connection;
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public UpdateOrderOption UpdateOrder {
            get {
                return this._updateOrder;
            }
            set {
                this._updateOrder = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.EditorAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterManagerPropertyEditor, Microso" +
            "ft.VSDesigner, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3" +
            "a", "System.Drawing.Design.UITypeEditor")]
        public tb_clienteTableAdapter tb_clienteTableAdapter {
            get {
                return this._tb_clienteTableAdapter;
            }
            set {
                this._tb_clienteTableAdapter = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.EditorAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterManagerPropertyEditor, Microso" +
            "ft.VSDesigner, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3" +
            "a", "System.Drawing.Design.UITypeEditor")]
        public tb_fornecedorTableAdapter tb_fornecedorTableAdapter {
            get {
                return this._tb_fornecedorTableAdapter;
            }
            set {
                this._tb_fornecedorTableAdapter = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.EditorAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterManagerPropertyEditor, Microso" +
            "ft.VSDesigner, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3" +
            "a", "System.Drawing.Design.UITypeEditor")]
        public tb_usuarioTableAdapter tb_usuarioTableAdapter {
            get {
                return this._tb_usuarioTableAdapter;
            }
            set {
                this._tb_usuarioTableAdapter = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.EditorAttribute("Microsoft.VSDesigner.DataSource.Design.TableAdapterManagerPropertyEditor, Microso" +
            "ft.VSDesigner, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3" +
            "a", "System.Drawing.Design.UITypeEditor")]
        public tb_produtosTableAdapter tb_produtosTableAdapter {
            get {
                return this._tb_produtosTableAdapter;
            }
            set {
                this._tb_produtosTableAdapter = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public bool BackupDataSetBeforeUpdate {
            get {
                return this._backupDataSetBeforeUpdate;
            }
            set {
                this._backupDataSetBeforeUpdate = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Browsable(false)]
        public global::System.Data.IDbConnection Connection {
            get {
                if ((this._connection != null)) {
                    return this._connection;
                }
                if (((this._tb_clienteTableAdapter != null) 
                            && (this._tb_clienteTableAdapter.Connection != null))) {
                    return this._tb_clienteTableAdapter.Connection;
                }
                if (((this._tb_fornecedorTableAdapter != null) 
                            && (this._tb_fornecedorTableAdapter.Connection != null))) {
                    return this._tb_fornecedorTableAdapter.Connection;
                }
                if (((this._tb_usuarioTableAdapter != null) 
                            && (this._tb_usuarioTableAdapter.Connection != null))) {
                    return this._tb_usuarioTableAdapter.Connection;
                }
                if (((this._tb_produtosTableAdapter != null) 
                            && (this._tb_produtosTableAdapter.Connection != null))) {
                    return this._tb_produtosTableAdapter.Connection;
                }
                return null;
            }
            set {
                this._connection = value;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        [global::System.ComponentModel.Browsable(false)]
        public int TableAdapterInstanceCount {
            get {
                int count = 0;
                if ((this._tb_clienteTableAdapter != null)) {
                    count = (count + 1);
                }
                if ((this._tb_fornecedorTableAdapter != null)) {
                    count = (count + 1);
                }
                if ((this._tb_usuarioTableAdapter != null)) {
                    count = (count + 1);
                }
                if ((this._tb_produtosTableAdapter != null)) {
                    count = (count + 1);
                }
                return count;
            }
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private int UpdateUpdatedRows(bancoDataSet1 dataSet, global::System.Collections.Generic.List<global::System.Data.DataRow> allChangedRows, global::System.Collections.Generic.List<global::System.Data.DataRow> allAddedRows) {
            int result = 0;
            if ((this._tb_clienteTableAdapter != null)) {
                global::System.Data.DataRow[] updatedRows = dataSet.tb_cliente.Select(null, null, global::System.Data.DataViewRowState.ModifiedCurrent);
                updatedRows = this.GetRealUpdatedRows(updatedRows, allAddedRows);
                if (((updatedRows != null) 
                            && (0 < updatedRows.Length))) {
                    result = (result + this._tb_clienteTableAdapter.Update(updatedRows));
                    allChangedRows.AddRange(updatedRows);
                }
            }
            if ((this._tb_fornecedorTableAdapter != null)) {
                global::System.Data.DataRow[] updatedRows = dataSet.tb_fornecedor.Select(null, null, global::System.Data.DataViewRowState.ModifiedCurrent);
                updatedRows = this.GetRealUpdatedRows(updatedRows, allAddedRows);
                if (((updatedRows != null) 
                            && (0 < updatedRows.Length))) {
                    result = (result + this._tb_fornecedorTableAdapter.Update(updatedRows));
                    allChangedRows.AddRange(updatedRows);
                }
            }
            if ((this._tb_usuarioTableAdapter != null)) {
                global::System.Data.DataRow[] updatedRows = dataSet.tb_usuario.Select(null, null, global::System.Data.DataViewRowState.ModifiedCurrent);
                updatedRows = this.GetRealUpdatedRows(updatedRows, allAddedRows);
                if (((updatedRows != null) 
                            && (0 < updatedRows.Length))) {
                    result = (result + this._tb_usuarioTableAdapter.Update(updatedRows));
                    allChangedRows.AddRange(updatedRows);
                }
            }
            if ((this._tb_produtosTableAdapter != null)) {
                global::System.Data.DataRow[] updatedRows = dataSet.tb_produtos.Select(null, null, global::System.Data.DataViewRowState.ModifiedCurrent);
                updatedRows = this.GetRealUpdatedRows(updatedRows, allAddedRows);
                if (((updatedRows != null) 
                            && (0 < updatedRows.Length))) {
                    result = (result + this._tb_produtosTableAdapter.Update(updatedRows));
                    allChangedRows.AddRange(updatedRows);
                }
            }
            return result;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private int UpdateInsertedRows(bancoDataSet1 dataSet, global::System.Collections.Generic.List<global::System.Data.DataRow> allAddedRows) {
            int result = 0;
            if ((this._tb_clienteTableAdapter != null)) {
                global::System.Data.DataRow[] addedRows = dataSet.tb_cliente.Select(null, null, global::System.Data.DataViewRowState.Added);
                if (((addedRows != null) 
                            && (0 < addedRows.Length))) {
                    result = (result + this._tb_clienteTableAdapter.Update(addedRows));
                    allAddedRows.AddRange(addedRows);
                }
            }
            if ((this._tb_fornecedorTableAdapter != null)) {
                global::System.Data.DataRow[] addedRows = dataSet.tb_fornecedor.Select(null, null, global::System.Data.DataViewRowState.Added);
                if (((addedRows != null) 
                            && (0 < addedRows.Length))) {
                    result = (result + this._tb_fornecedorTableAdapter.Update(addedRows));
                    allAddedRows.AddRange(addedRows);
                }
            }
            if ((this._tb_usuarioTableAdapter != null)) {
                global::System.Data.DataRow[] addedRows = dataSet.tb_usuario.Select(null, null, global::System.Data.DataViewRowState.Added);
                if (((addedRows != null) 
                            && (0 < addedRows.Length))) {
                    result = (result + this._tb_usuarioTableAdapter.Update(addedRows));
                    allAddedRows.AddRange(addedRows);
                }
            }
            if ((this._tb_produtosTableAdapter != null)) {
                global::System.Data.DataRow[] addedRows = dataSet.tb_produtos.Select(null, null, global::System.Data.DataViewRowState.Added);
                if (((addedRows != null) 
                            && (0 < addedRows.Length))) {
                    result = (result + this._tb_produtosTableAdapter.Update(addedRows));
                    allAddedRows.AddRange(addedRows);
                }
            }
            return result;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private int UpdateDeletedRows(bancoDataSet1 dataSet, global::System.Collections.Generic.List<global::System.Data.DataRow> allChangedRows) {
            int result = 0;
            if ((this._tb_produtosTableAdapter != null)) {
                global::System.Data.DataRow[] deletedRows = dataSet.tb_produtos.Select(null, null, global::System.Data.DataViewRowState.Deleted);
                if (((deletedRows != null) 
                            && (0 < deletedRows.Length))) {
                    result = (result + this._tb_produtosTableAdapter.Update(deletedRows));
                    allChangedRows.AddRange(deletedRows);
                }
            }
            if ((this._tb_usuarioTableAdapter != null)) {
                global::System.Data.DataRow[] deletedRows = dataSet.tb_usuario.Select(null, null, global::System.Data.DataViewRowState.Deleted);
                if (((deletedRows != null) 
                            && (0 < deletedRows.Length))) {
                    result = (result + this._tb_usuarioTableAdapter.Update(deletedRows));
                    allChangedRows.AddRange(deletedRows);
                }
            }
            if ((this._tb_fornecedorTableAdapter != null)) {
                global::System.Data.DataRow[] deletedRows = dataSet.tb_fornecedor.Select(null, null, global::System.Data.DataViewRowState.Deleted);
                if (((deletedRows != null) 
                            && (0 < deletedRows.Length))) {
                    result = (result + this._tb_fornecedorTableAdapter.Update(deletedRows));
                    allChangedRows.AddRange(deletedRows);
                }
            }
            if ((this._tb_clienteTableAdapter != null)) {
                global::System.Data.DataRow[] deletedRows = dataSet.tb_cliente.Select(null, null, global::System.Data.DataViewRowState.Deleted);
                if (((deletedRows != null) 
                            && (0 < deletedRows.Length))) {
                    result = (result + this._tb_clienteTableAdapter.Update(deletedRows));
                    allChangedRows.AddRange(deletedRows);
                }
            }
            return result;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private global::System.Data.DataRow[] GetRealUpdatedRows(global::System.Data.DataRow[] updatedRows, global::System.Collections.Generic.List<global::System.Data.DataRow> allAddedRows) {
            if (((updatedRows == null) 
                        || (updatedRows.Length < 1))) {
                return updatedRows;
            }
            if (((allAddedRows == null) 
                        || (allAddedRows.Count < 1))) {
                return updatedRows;
            }
            global::System.Collections.Generic.List<global::System.Data.DataRow> realUpdatedRows = new global::System.Collections.Generic.List<global::System.Data.DataRow>();
            for (int i = 0; (i < updatedRows.Length); i = (i + 1)) {
                global::System.Data.DataRow row = updatedRows[i];
                if ((allAddedRows.Contains(row) == false)) {
                    realUpdatedRows.Add(row);
                }
            }
            return realUpdatedRows.ToArray();
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public virtual int UpdateAll(bancoDataSet1 dataSet) {
            if ((dataSet == null)) {
                throw new global::System.ArgumentNullException("dataSet");
            }
            if ((dataSet.HasChanges() == false)) {
                return 0;
            }
            if (((this._tb_clienteTableAdapter != null) 
                        && (this.MatchTableAdapterConnection(this._tb_clienteTableAdapter.Connection) == false))) {
                throw new global::System.ArgumentException("Todos os TableAdapters gerenciados por um TableAdapterManager devem usar a mesma " +
                        "cadeia de conexão.");
            }
            if (((this._tb_fornecedorTableAdapter != null) 
                        && (this.MatchTableAdapterConnection(this._tb_fornecedorTableAdapter.Connection) == false))) {
                throw new global::System.ArgumentException("Todos os TableAdapters gerenciados por um TableAdapterManager devem usar a mesma " +
                        "cadeia de conexão.");
            }
            if (((this._tb_usuarioTableAdapter != null) 
                        && (this.MatchTableAdapterConnection(this._tb_usuarioTableAdapter.Connection) == false))) {
                throw new global::System.ArgumentException("Todos os TableAdapters gerenciados por um TableAdapterManager devem usar a mesma " +
                        "cadeia de conexão.");
            }
            if (((this._tb_produtosTableAdapter != null) 
                        && (this.MatchTableAdapterConnection(this._tb_produtosTableAdapter.Connection) == false))) {
                throw new global::System.ArgumentException("Todos os TableAdapters gerenciados por um TableAdapterManager devem usar a mesma " +
                        "cadeia de conexão.");
            }
            global::System.Data.IDbConnection workConnection = this.Connection;
            if ((workConnection == null)) {
                throw new global::System.ApplicationException("TableAdapterManager não contém informações de conexão. Defina cada propriedade Ta" +
                        "bleAdapter de TableAdapterManager como uma instância válida de TableAdapter.");
            }
            bool workConnOpened = false;
            if (((workConnection.State & global::System.Data.ConnectionState.Broken) 
                        == global::System.Data.ConnectionState.Broken)) {
                workConnection.Close();
            }
            if ((workConnection.State == global::System.Data.ConnectionState.Closed)) {
                workConnection.Open();
                workConnOpened = true;
            }
            global::System.Data.IDbTransaction workTransaction = workConnection.BeginTransaction();
            if ((workTransaction == null)) {
                throw new global::System.ApplicationException("Não é possível iniciar a transação. Os dados de conexão atuais não oferecem supor" +
                        "te às transações ou o estado atual não permite que a transação inicie.");
            }
            global::System.Collections.Generic.List<global::System.Data.DataRow> allChangedRows = new global::System.Collections.Generic.List<global::System.Data.DataRow>();
            global::System.Collections.Generic.List<global::System.Data.DataRow> allAddedRows = new global::System.Collections.Generic.List<global::System.Data.DataRow>();
            global::System.Collections.Generic.List<global::System.Data.Common.DataAdapter> adaptersWithAcceptChangesDuringUpdate = new global::System.Collections.Generic.List<global::System.Data.Common.DataAdapter>();
            global::System.Collections.Generic.Dictionary<object, global::System.Data.IDbConnection> revertConnections = new global::System.Collections.Generic.Dictionary<object, global::System.Data.IDbConnection>();
            int result = 0;
            global::System.Data.DataSet backupDataSet = null;
            if (this.BackupDataSetBeforeUpdate) {
                backupDataSet = new global::System.Data.DataSet();
                backupDataSet.Merge(dataSet);
            }
            try {
                if ((this._tb_clienteTableAdapter != null)) {
                    revertConnections.Add(this._tb_clienteTableAdapter, this._tb_clienteTableAdapter.Connection);
                    this._tb_clienteTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(workConnection));
                    this._tb_clienteTableAdapter.Transaction = ((global::System.Data.SqlClient.SqlTransaction)(workTransaction));
                    if (this._tb_clienteTableAdapter.Adapter.AcceptChangesDuringUpdate) {
                        this._tb_clienteTableAdapter.Adapter.AcceptChangesDuringUpdate = false;
                        adaptersWithAcceptChangesDuringUpdate.Add(this._tb_clienteTableAdapter.Adapter);
                    }
                }
                if ((this._tb_fornecedorTableAdapter != null)) {
                    revertConnections.Add(this._tb_fornecedorTableAdapter, this._tb_fornecedorTableAdapter.Connection);
                    this._tb_fornecedorTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(workConnection));
                    this._tb_fornecedorTableAdapter.Transaction = ((global::System.Data.SqlClient.SqlTransaction)(workTransaction));
                    if (this._tb_fornecedorTableAdapter.Adapter.AcceptChangesDuringUpdate) {
                        this._tb_fornecedorTableAdapter.Adapter.AcceptChangesDuringUpdate = false;
                        adaptersWithAcceptChangesDuringUpdate.Add(this._tb_fornecedorTableAdapter.Adapter);
                    }
                }
                if ((this._tb_usuarioTableAdapter != null)) {
                    revertConnections.Add(this._tb_usuarioTableAdapter, this._tb_usuarioTableAdapter.Connection);
                    this._tb_usuarioTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(workConnection));
                    this._tb_usuarioTableAdapter.Transaction = ((global::System.Data.SqlClient.SqlTransaction)(workTransaction));
                    if (this._tb_usuarioTableAdapter.Adapter.AcceptChangesDuringUpdate) {
                        this._tb_usuarioTableAdapter.Adapter.AcceptChangesDuringUpdate = false;
                        adaptersWithAcceptChangesDuringUpdate.Add(this._tb_usuarioTableAdapter.Adapter);
                    }
                }
                if ((this._tb_produtosTableAdapter != null)) {
                    revertConnections.Add(this._tb_produtosTableAdapter, this._tb_produtosTableAdapter.Connection);
                    this._tb_produtosTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(workConnection));
                    this._tb_produtosTableAdapter.Transaction = ((global::System.Data.SqlClient.SqlTransaction)(workTransaction));
                    if (this._tb_produtosTableAdapter.Adapter.AcceptChangesDuringUpdate) {
                        this._tb_produtosTableAdapter.Adapter.AcceptChangesDuringUpdate = false;
                        adaptersWithAcceptChangesDuringUpdate.Add(this._tb_produtosTableAdapter.Adapter);
                    }
                }
                if ((this.UpdateOrder == UpdateOrderOption.UpdateInsertDelete)) {
                    result = (result + this.UpdateUpdatedRows(dataSet, allChangedRows, allAddedRows));
                    result = (result + this.UpdateInsertedRows(dataSet, allAddedRows));
                }
                else {
                    result = (result + this.UpdateInsertedRows(dataSet, allAddedRows));
                    result = (result + this.UpdateUpdatedRows(dataSet, allChangedRows, allAddedRows));
                }
                result = (result + this.UpdateDeletedRows(dataSet, allChangedRows));
                workTransaction.Commit();
                if ((0 < allAddedRows.Count)) {
                    global::System.Data.DataRow[] rows = new System.Data.DataRow[allAddedRows.Count];
                    allAddedRows.CopyTo(rows);
                    for (int i = 0; (i < rows.Length); i = (i + 1)) {
                        global::System.Data.DataRow row = rows[i];
                        row.AcceptChanges();
                    }
                }
                if ((0 < allChangedRows.Count)) {
                    global::System.Data.DataRow[] rows = new System.Data.DataRow[allChangedRows.Count];
                    allChangedRows.CopyTo(rows);
                    for (int i = 0; (i < rows.Length); i = (i + 1)) {
                        global::System.Data.DataRow row = rows[i];
                        row.AcceptChanges();
                    }
                }
            }
            catch (global::System.Exception ex) {
                workTransaction.Rollback();
                if (this.BackupDataSetBeforeUpdate) {
                    global::System.Diagnostics.Debug.Assert((backupDataSet != null));
                    dataSet.Clear();
                    dataSet.Merge(backupDataSet);
                }
                else {
                    if ((0 < allAddedRows.Count)) {
                        global::System.Data.DataRow[] rows = new System.Data.DataRow[allAddedRows.Count];
                        allAddedRows.CopyTo(rows);
                        for (int i = 0; (i < rows.Length); i = (i + 1)) {
                            global::System.Data.DataRow row = rows[i];
                            row.AcceptChanges();
                            row.SetAdded();
                        }
                    }
                }
                throw ex;
            }
            finally {
                if (workConnOpened) {
                    workConnection.Close();
                }
                if ((this._tb_clienteTableAdapter != null)) {
                    this._tb_clienteTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(revertConnections[this._tb_clienteTableAdapter]));
                    this._tb_clienteTableAdapter.Transaction = null;
                }
                if ((this._tb_fornecedorTableAdapter != null)) {
                    this._tb_fornecedorTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(revertConnections[this._tb_fornecedorTableAdapter]));
                    this._tb_fornecedorTableAdapter.Transaction = null;
                }
                if ((this._tb_usuarioTableAdapter != null)) {
                    this._tb_usuarioTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(revertConnections[this._tb_usuarioTableAdapter]));
                    this._tb_usuarioTableAdapter.Transaction = null;
                }
                if ((this._tb_produtosTableAdapter != null)) {
                    this._tb_produtosTableAdapter.Connection = ((global::System.Data.SqlClient.SqlConnection)(revertConnections[this._tb_produtosTableAdapter]));
                    this._tb_produtosTableAdapter.Transaction = null;
                }
                if ((0 < adaptersWithAcceptChangesDuringUpdate.Count)) {
                    global::System.Data.Common.DataAdapter[] adapters = new System.Data.Common.DataAdapter[adaptersWithAcceptChangesDuringUpdate.Count];
                    adaptersWithAcceptChangesDuringUpdate.CopyTo(adapters);
                    for (int i = 0; (i < adapters.Length); i = (i + 1)) {
                        global::System.Data.Common.DataAdapter adapter = adapters[i];
                        adapter.AcceptChangesDuringUpdate = true;
                    }
                }
            }
            return result;
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected virtual void SortSelfReferenceRows(global::System.Data.DataRow[] rows, global::System.Data.DataRelation relation, bool childFirst) {
            global::System.Array.Sort<global::System.Data.DataRow>(rows, new SelfReferenceComparer(relation, childFirst));
        }
        
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        protected virtual bool MatchTableAdapterConnection(global::System.Data.IDbConnection inputConnection) {
            if ((this._connection != null)) {
                return true;
            }
            if (((this.Connection == null) 
                        || (inputConnection == null))) {
                return true;
            }
            if (string.Equals(this.Connection.ConnectionString, inputConnection.ConnectionString, global::System.StringComparison.Ordinal)) {
                return true;
            }
            return false;
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        public enum UpdateOrderOption {
            
            InsertUpdateDelete = 0,
            
            UpdateInsertDelete = 1,
        }
        
        [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
        private class SelfReferenceComparer : object, global::System.Collections.Generic.IComparer<global::System.Data.DataRow> {
            
            private global::System.Data.DataRelation _relation;
            
            private int _childFirst;
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            internal SelfReferenceComparer(global::System.Data.DataRelation relation, bool childFirst) {
                this._relation = relation;
                if (childFirst) {
                    this._childFirst = -1;
                }
                else {
                    this._childFirst = 1;
                }
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            private global::System.Data.DataRow GetRoot(global::System.Data.DataRow row, out int distance) {
                global::System.Diagnostics.Debug.Assert((row != null));
                global::System.Data.DataRow root = row;
                distance = 0;

                global::System.Collections.Generic.IDictionary<global::System.Data.DataRow, global::System.Data.DataRow> traversedRows = new global::System.Collections.Generic.Dictionary<global::System.Data.DataRow, global::System.Data.DataRow>();
                traversedRows[row] = row;

                global::System.Data.DataRow parent = row.GetParentRow(this._relation, global::System.Data.DataRowVersion.Default);
                for (
                ; ((parent != null) 
                            && (traversedRows.ContainsKey(parent) == false)); 
                ) {
                    distance = (distance + 1);
                    root = parent;
                    traversedRows[parent] = parent;
                    parent = parent.GetParentRow(this._relation, global::System.Data.DataRowVersion.Default);
                }

                if ((distance == 0)) {
                    traversedRows.Clear();
                    traversedRows[row] = row;
                    parent = row.GetParentRow(this._relation, global::System.Data.DataRowVersion.Original);
                    for (
                    ; ((parent != null) 
                                && (traversedRows.ContainsKey(parent) == false)); 
                    ) {
                        distance = (distance + 1);
                        root = parent;
                        traversedRows[parent] = parent;
                        parent = parent.GetParentRow(this._relation, global::System.Data.DataRowVersion.Original);
                    }
                }

                return root;
            }
            
            [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
            [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "17.0.0.0")]
            public int Compare(global::System.Data.DataRow row1, global::System.Data.DataRow row2) {
                if (object.ReferenceEquals(row1, row2)) {
                    return 0;
                }
                if ((row1 == null)) {
                    return -1;
                }
                if ((row2 == null)) {
                    return 1;
                }

                int distance1 = 0;
                global::System.Data.DataRow root1 = this.GetRoot(row1, out distance1);

                int distance2 = 0;
                global::System.Data.DataRow root2 = this.GetRoot(row2, out distance2);

                if (object.ReferenceEquals(root1, root2)) {
                    return (this._childFirst * distance1.CompareTo(distance2));
                }
                else {
                    global::System.Diagnostics.Debug.Assert(((root1.Table != null) 
                                    && (root2.Table != null)));
                    if ((root1.Table.Rows.IndexOf(root1) < root2.Table.Rows.IndexOf(root2))) {
                        return -1;
                    }
                    else {
                        return 1;
                    }
                }
            }
        }
    }
}

#pragma warning restore 1591